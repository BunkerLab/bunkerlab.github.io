# -*- coding: utf-8 -*-
"""SkinCat: "plugin interno" de la skin que alimenta las filas del Home.

URL:  plugin://skin.cat/?pages=N&src=<ruta de Palantir>
      plugin://skin.cat/?mode=sheet&season=<n>&src=<serie>   (capítulos de una serie para la hoja lateral)
      plugin://skin.cat/?mode=seasons&sel=<n>&src=<serie>    (chips de temporada)
      plugin://skin.cat/?mode=results&t=..&cat=..    (resultados de búsqueda)

      src=skincat://favourites   (fila "Favoritos de Kodi": los favoritos que el menú contextual de Kodi guarda en favourites.xml;
                                  cada uno recupera su ficha completa de la memoria de títulos de la skin)

Si la carpeta de una fila solo contiene CATEGORÍAS (p. ej. "Favoritos": "Películas favoritas (3)", "Series (0)"...)
se aplana: la fila muestra directamente los títulos de todas ellas, no las carpetas hijas.

Une las N primeras páginas de la carpeta de Palantir en una sola lista. El botón "más..." de Palantir
(una carpeta que abre la página siguiente) no se muestra: se sustituye por un único elemento
"Cargar más" (propiedad skincat_more=1) que la skin intercepta para pedir una página más SIN salir de la fila.
Las páginas se guardan 15 minutos en caché para que ampliar la fila sea instantáneo.
"""
import hashlib
import json
import os
import re
import sqlite3
import sys
import time

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import skincat_watch as watch

SKIN_ID = "skin.cat"
CACHE_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s/pagecache/" % SKIN_ID)
CACHE_TTL = 15 * 60
MAX_PAGES = 20
PROPS = ["title", "plot", "year", "genre", "mpaa", "runtime", "art", "imdbnumber", "premiered",
         "originaltitle", "tagline", "studio", "country", "director", "season", "episode"]
TAGS = re.compile(r"\[/?(COLOR[^\]]*|B|I|CR)\]", re.I)


def log(msg):
    xbmc.log("[SkinCat rows] %s" % msg, xbmc.LOGINFO)


FAV_PATH = "skincat://favourites"
SORT_PAGES = 10   # con un orden activo se cargan hasta 10 páginas de Palantir (paginan alfabéticamente: ordenar solo la primera engañaría)
ADDONS_PATH = "skincat://addons"
ROOT_URL = "plugin://plugin.video.palantir3/"
META_DB = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID), "itemmeta.db")
META_FIELDS = ("label", "title", "plot", "year", "genre", "mpaa", "runtime", "art", "imdbnumber", "premiered",
               "originaltitle", "tagline", "studio", "country", "director", "type", "filetype", "file", "season", "episode")
META_MAX = 30000


def title_key(label):
    """"Ali G: Kién es yo? (2026)" -> clave estable. La ruta de Palantir de un mismo título cambia según la lista de la que venga."""
    t = re.sub(r"\[[^\]]*\]", "", label or "")
    return re.sub(r"\s+", " ", t).strip().lower()


def _meta_con():
    os.makedirs(os.path.dirname(META_DB), exist_ok=True)
    con = sqlite3.connect(META_DB, timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS meta (path TEXT PRIMARY KEY, json TEXT, ts REAL)")
    con.execute("CREATE TABLE IF NOT EXISTS bytitle (tkey TEXT PRIMARY KEY, json TEXT, ts REAL)")
    return con


def remember(files):
    """Guarda la ficha de cada título que pasa por la skin: así un favorito de Kodi (que solo guarda nombre, miniatura y ruta)
    recupera sinopsis, géneros, id de TMDB (para la nota de IMDb)... Se indexa por ruta y por nombre+año."""
    now = time.time()
    by_path, by_title = [], []
    for f in files:
        if f.get("file") and is_title(f):
            js = json.dumps({k: f.get(k) for k in META_FIELDS})
            by_path.append((f["file"], js, now))
            by_title.append((title_key(f.get("label")), js, now))
    if not by_path:
        return
    try:
        con = _meta_con()
        con.executemany("INSERT OR REPLACE INTO meta VALUES (?,?,?)", by_path)
        con.executemany("INSERT OR REPLACE INTO bytitle VALUES (?,?,?)", by_title)
        for table in ("meta", "bytitle"):
            n = con.execute("SELECT COUNT(*) FROM %s" % table).fetchone()[0]
            if n > META_MAX:  # poda: se conservan los más recientes
                key = "path" if table == "meta" else "tkey"
                con.execute("DELETE FROM %s WHERE %s IN (SELECT %s FROM %s ORDER BY ts ASC LIMIT ?)" % (table, key, key, table), (n - META_MAX,))
        con.commit()
        con.close()
    except sqlite3.Error as e:
        log("memoria de títulos: %r" % e)


def recall(path, label=""):
    try:
        con = _meta_con()
        row = con.execute("SELECT json FROM meta WHERE path=?", (path,)).fetchone()
        if not row and label:
            row = con.execute("SELECT json FROM bytitle WHERE tkey=?", (title_key(label),)).fetchone()
        con.close()
        return json.loads(row[0]) if row else None
    except (sqlite3.Error, ValueError):
        return None


def favourites(handle):
    """Fila "Favoritos de Kodi": favourites.xml, el más reciente primero."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "Favourites.GetFavourites",
           "params": {"properties": ["path", "window", "windowparameter", "thumbnail"]}}
    favs = (json.loads(xbmc.executeJSONRPC(json.dumps(req))).get("result") or {}).get("favourites") or []
    entries = []
    for fav in reversed(favs):
        kind = fav.get("type")
        if kind == "media" and fav.get("path"):
            path, isdir = fav["path"], False
        elif kind == "window" and fav.get("windowparameter"):
            path, isdir = fav["windowparameter"], True
        else:
            continue  # scripts, apps, etc.
        meta = recall(path, fav.get("title", ""))
        if meta:
            meta["file"], meta["filetype"] = path, ("directory" if isdir else "file")
            if not meta.get("label"):
                meta["label"] = fav.get("title", "")
            entries.append(make_item(meta))
            continue
        li = xbmcgui.ListItem(fav.get("title", ""), path=path)
        if fav.get("thumbnail"):
            li.setArt({"poster": fav["thumbnail"], "thumb": fav["thumbnail"]})
        tag = li.getVideoInfoTag()
        tag.setMediaType("tvshow" if isdir else "movie")
        if not isdir:
            li.setProperty("IsPlayable", "true")
        entries.append((path, li, isdir))
    if not entries:
        entries.append(note_item("Aún no tienes favoritos en Kodi"))
    xbmcplugin.setContent(handle, "movies")
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def favourites_category():
    """Elemento extra de la raíz del selector: la fuente "Favoritos de Kodi"."""
    li = xbmcgui.ListItem("[COLOR ffffd700]★ Favoritos de Kodi[/COLOR]", path=FAV_PATH)
    return FAV_PATH, li, True


def sort_entries(entries, mode):
    """Ordena los títulos de una fila. mode: yd = año descendente (lo más nuevo primero), ya = ascendente, az = alfabético.
    Los tiles informativos ("Cargar más", avisos) se quedan al final; sin año, al final de su grupo; las letras antes que
    cifras y símbolos (así "Zodiaco" va antes que "007")."""
    tiles = [e for e in entries if e[1].getProperty("skincat_tile")]
    items = [e for e in entries if not e[1].getProperty("skincat_tile")]

    def name(e):
        return TAGS.sub("", e[1].getLabel()).strip().lower()

    def year(e):
        try:
            y = int(e[1].getVideoInfoTag().getYear())
        except (ValueError, TypeError):
            y = 0
        if not y:
            m = re.search(r"\((\d{4})\)", e[1].getLabel())
            y = int(m.group(1)) if m else 0
        return y

    def az(e):
        n = re.sub(r"^[^\w]+", "", name(e))
        return (not n[:1].isalpha(), n)

    if mode == "az":
        items.sort(key=az)
    elif mode in ("yd", "ya"):
        have = sorted([e for e in items if year(e)], key=lambda e: (year(e), az(e)), reverse=(mode == "yd"))
        if mode == "yd":  # a igualdad de año, alfabético ascendente
            have.sort(key=lambda e: (-year(e), az(e)))
        items = have + [e for e in items if not year(e)]
    return items + tiles


def video_addons(handle):
    """Fuente "Add-ons de vídeo": un cartel por cada add-on de vídeo instalado y activo (menos Palantir, que ya tiene sus filas).
    Pulsar uno abre el add-on en la ventana de vídeos; elegirlo en el selector pone SU contenido en la fila."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddons",
           "params": {"type": "xbmc.addon.video", "content": "video", "enabled": True,
                      "properties": ["name", "summary", "thumbnail", "fanart"]}}
    found = (json.loads(xbmc.executeJSONRPC(json.dumps(req))).get("result") or {}).get("addons") or []
    entries = []
    for a in sorted(found, key=lambda a: (a.get("name") or "").lower()):
        if a.get("addonid") in ("plugin.video.palantir3", SKIN_ID):
            continue
        path = "plugin://%s/" % a["addonid"]
        li = xbmcgui.ListItem(a.get("name") or a["addonid"], path=path)
        art = {}
        if a.get("thumbnail"):
            art["poster"] = art["thumb"] = art["icon"] = a["thumbnail"]
        if a.get("fanart"):
            art["fanart"] = a["fanart"]
        if art:
            li.setArt(art)
        li.getVideoInfoTag().setPlot(a.get("summary") or "")
        entries.append((path, li, True))
    if not entries:
        entries.append(note_item("No hay otros add-ons de vídeo instalados"))
    xbmcplugin.setContent(handle, "movies")
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def addons_category():
    """Elemento extra de la raíz del selector: la fuente "Add-ons de vídeo"."""
    li = xbmcgui.ListItem("Add-ons de vídeo", path=ADDONS_PATH)
    return ADDONS_PATH, li, True


def generic_row(handle, src):
    """Fila con el contenido de cualquier otro add-on de vídeo: se muestra tal cual lo da el add-on (sin aplanar ni filtrar)."""
    entries = []
    try:
        for f in get_page(src)[:80]:
            entries.append(make_item(f, generic=True))
    except Exception as e:
        log("error en add-on externo: %r" % e)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    if not entries:
        entries.append(note_item("Este add-on no muestra nada aquí"))
    xbmcplugin.setContent(handle, "movies")
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def get_page(path):
    """Devuelve la lista de ficheros de una carpeta de Palantir (con caché)."""
    os.makedirs(CACHE_DIR, exist_ok=True)
    cf = os.path.join(CACHE_DIR, hashlib.md5(path.encode("utf-8")).hexdigest() + ".json")
    try:
        if time.time() - os.path.getmtime(cf) < CACHE_TTL:
            with open(cf, "r", encoding="utf-8") as f:
                return json.load(f)
    except (OSError, ValueError):
        pass
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
           "params": {"directory": path, "media": "video", "properties": PROPS}}
    res = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    files = res.get("result", {}).get("files")
    if files is None:
        raise RuntimeError("Files.GetDirectory falló: %s" % res.get("error"))
    try:
        with open(cf, "w", encoding="utf-8") as f:
            json.dump(files, f)
    except OSError:
        pass
    remember(files)
    return files


def is_search(f):
    """Elementos de búsqueda de Palantir ("Buscar:", "Buscar por título"...): al entrar abren un teclado."""
    return TAGS.sub("", f.get("label", "")).strip().lower().startswith("buscar")


def is_more(f):
    return f.get("filetype") == "directory" and TAGS.sub("", f.get("label", "")).strip().lower() in ("más...", "más…", "mas...")


def is_title(f):
    """Un título (película/serie/capítulo) lleva id de TMDB o cartel; una categoría o un separador no."""
    return bool(f.get("imdbnumber")) or bool((f.get("art") or {}).get("poster"))


def is_category(f):
    return f.get("filetype") == "directory" and not is_title(f) and not is_search(f) and not is_more(f)


def note_item(text):
    """Tile informativo no pulsable (skincat_tile=1)."""
    li = xbmcgui.ListItem(text)
    li.setProperty("skincat_tile", "1")
    return "plugin://%s/?note=1" % SKIN_ID, li, False


def cut_at_search(files):
    """"Buscar:" abre un bloque de búsquedas (abren el teclado) que ocupa el resto de la lista: se corta ahí."""
    out = []
    for f in files:
        if is_search(f) and f.get("filetype") == "file":
            break
        out.append(f)
    return out


def flatten(files, entries):
    """Añade a `entries` los títulos de todas las categorías hijas (sin las vacías "(0)"), sin repetir."""
    seen = {e[0] for e in entries}
    for cat in [f for f in cut_at_search(files) if is_category(f)][:12]:
        if re.search(r"\(0\)\s*$", TAGS.sub("", cat.get("label", "")).strip()):
            continue
        path = cat["file"]
        for _ in range(2):
            nxt = None
            try:
                page = get_page(path)
            except Exception as e:  # una categoría hija que falla (p. ej. vacía) no debe romper la fila
                log("categoría omitida (%s): %r" % (TAGS.sub("", cat.get("label", ""))[:30], e))
                break
            for f in page:
                if is_more(f):
                    nxt = f["file"]
                elif is_title(f) and f["file"] not in seen:
                    seen.add(f["file"])
                    entries.append(make_item(f))
            if nxt is None:
                break
            path = nxt


def season_folders(files):
    """Carpetas de temporada de una serie ("Temporada 3", "Especiales"), ordenadas: 1, 2, 3... y Especiales al final."""
    out = []
    for f in files:
        if f.get("filetype") != "directory" or is_search(f) or is_more(f):
            continue
        lab = TAGS.sub("", f.get("label", "")).strip()
        m = re.search(r"(?:temporada|season)\s*(\d+)", lab, re.I)
        if m:
            num = int(m.group(1))
        elif re.search(r"especial", lab, re.I):
            num = 0
        elif isinstance(f.get("season"), int) and f.get("season") >= 0:  # (Stranger Things: la carpeta lleva id TMDB)
            num = f["season"]
        else:
            continue
        out.append((num, lab, f))
    out.sort(key=lambda t: (t[0] == 0, t[0]))
    return out


def chip_label(num, lab):
    return "Esp." if num == 0 else "T%d" % num


def default_season(seasons):
    return seasons[0][0] if seasons else None


def sheet_seasons(handle, src, sel):
    """?mode=seasons: un chip por temporada (solo si hay más de una). `sel` = temporada elegida ("" = la primera)."""
    entries = []
    try:
        seasons = season_folders(get_page(src))
        if len(seasons) > 1:
            current = int(sel) if sel.isdigit() else default_season(seasons)
            for idx, (num, lab, f) in enumerate(seasons):
                li = xbmcgui.ListItem(chip_label(num, lab))
                li.setProperty("season", str(num))
                li.setProperty("idx", str(idx))
                if num == current:
                    li.setProperty("selected", "1")
                entries.append(("plugin://%s/?chip=%d" % (SKIN_ID, num), li, False))
    except Exception as e:
        log("error en seasons: %r" % e)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def sheet(handle, src, season=""):
    """?mode=sheet: capítulos de una serie en lista plana. Si Palantir ofrece temporadas, solo las de la elegida
    (`season`, por defecto la primera)."""
    entries = []
    try:
        files = get_page(src)
        seasons = season_folders(files)
        label = ""
        if seasons:
            want = int(season) if season.isdigit() else default_season(seasons)
            num, lab, folder = next((t for t in seasons if t[0] == want), seasons[0])
            files, label = get_page(folder["file"]), lab
        for f in files:
            if is_episode(f):
                path, li, isdir = make_item(f)
                li.setLabel(TAGS.sub("", f.get("label", "")).strip())  # sin el dorado de Palantir: se confunde con la selección
                if f.get("season"):
                    li.getVideoInfoTag().setSeason(int(f["season"]))
                if f.get("episode"):
                    li.getVideoInfoTag().setEpisode(int(f["episode"]))
                li.getVideoInfoTag().setMediaType("episode")
                if label:
                    li.setProperty("season_label", label)
                entries.append((path, li, isdir))
    except Exception as e:
        log("error en sheet: %r" % e)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    if not entries:
        entries.append(note_item("No hay capítulos disponibles"))
    xbmcplugin.setContent(handle, "episodes")
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def is_episode(f):
    return f.get("filetype") == "file" and ((f.get("episode") or 0) > 0 or re.match(r"\s*\d+x\d+", TAGS.sub("", f.get("label", ""))))


def ep_number(f):
    if (f.get("episode") or 0) > 0:
        return int(f["episode"])
    m = re.match(r"\s*\d+x(\d+)", TAGS.sub("", f.get("label", "")))
    return int(m.group(1)) if m else 0


def next_episode(showsrc, season, episode):
    """Capítulo siguiente a (temporada, capítulo) en el listado de Palantir de la serie, o None si era el último."""
    files = get_page(showsrc)
    seasons = [t for t in season_folders(files) if t[0] > 0]
    if not seasons:
        eps = sorted((f for f in files if is_episode(f)), key=ep_number)
        return next((f for f in eps if ep_number(f) > episode), None)
    for num, _lab, folder in seasons:
        if num < season:
            continue
        eps = sorted((f for f in get_page(folder["file"]) if is_episode(f)), key=ep_number)
        nxt = next((f for f in eps if ep_number(f) > (episode if num == season else 0)), None)
        if nxt:
            return nxt
    return None


def continue_row(handle):
    """Fila 0 "Continuar viendo" (scripts/skincat_watch.py): películas a medias y el capítulo en curso/siguiente de cada serie."""
    entries = []
    for e in watch.entries():
        try:
            if e["kind"] == "episode" and e.get("done"):
                nxt = next_episode(e["showsrc"], e["season"] or 1, e["episode"] or 0)
                if not nxt:  # serie terminada
                    watch.delete(e["key"])
                    continue
                m = nxt
                e.update(path=nxt["file"], label=watch.clean(nxt.get("label")), title=watch.clean(nxt.get("label")),
                         season=int(nxt.get("season") or 0) or e["season"], episode=ep_number(nxt), plot=nxt.get("plot") or "",
                         thumb=(nxt.get("art") or {}).get("thumb") or e.get("thumb") or "", pos=0.0, total=0.0, done=0)
                watch.put(e)
        except Exception as ex:
            log("continuar: no se pudo resolver el siguiente capítulo de %r: %r" % (e.get("show"), ex))
            continue
        isep = e["kind"] == "episode"
        label = ("%s · %dx%02d" % (e["show"], e["season"], e["episode"])) if isep and e["season"] else (e["show"] if isep else e["title"])
        li = xbmcgui.ListItem(label, path=e["path"])
        tag = li.getVideoInfoTag()
        tag.setTitle(label)
        tag.setMediaType("tvshow" if isep else "movie")  # tvshow: la nota IMDb se busca como serie; no es carpeta, así que OK reproduce
        if e.get("plot"):
            tag.setPlot(("%s\n\n%s" % (e["title"], e["plot"])) if isep and e["title"] else e["plot"])
        if str(e.get("year") or "").isdigit():
            tag.setYear(int(e["year"]))
        if e.get("tmdb"):
            tag.setIMDBNumber(str(e["tmdb"]))
            tag.setUniqueIDs({"tmdb": str(e["tmdb"])}, "tmdb")
        art = {k: v for k, v in (("poster", e.get("poster")), ("thumb", e.get("thumb") or e.get("poster")), ("fanart", e.get("fanart"))) if v}
        li.setArt(art)
        resume = int(e["pos"]) if (e.get("pos") or 0) >= watch.MIN_SECONDS and not e.get("done") else 0
        if resume and (e.get("total") or 0) > 0:
            tag.setResumePoint(float(resume), float(e["total"]))
            li.setProperty("resume", str(resume))
        li.setProperty("showsrc", e.get("showsrc") or "")
        li.setProperty("season", str(e.get("season") or ""))
        li.setProperty("episode", str(e.get("episode") or ""))
        li.setProperty("IsPlayable", "true")
        entries.append((e["path"], li, False))
    if not entries:
        entries.append(note_item("Nada que continuar"))
    xbmcplugin.setContent(handle, "movies")
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def make_item(f, generic=False):
    label = f.get("label") or f.get("title") or ""
    isdir = f.get("filetype") == "directory"
    li = xbmcgui.ListItem(label, path=f["file"])
    tag = li.getVideoInfoTag()
    tag.setTitle(f.get("title") or label)
    if f.get("plot"):
        tag.setPlot(f["plot"])
    if f.get("year"):
        tag.setYear(int(f["year"]))
    if f.get("genre"):
        tag.setGenres(list(f["genre"]))
    if f.get("mpaa"):
        tag.setMpaa(f["mpaa"])
    if f.get("runtime"):
        tag.setDuration(int(f["runtime"]))
    if f.get("premiered"):
        tag.setPremiered(f["premiered"])
    if f.get("type") in ("movie", "tvshow", "season", "episode"):
        tag.setMediaType(f["type"])
    if f.get("imdbnumber"):
        # Palantir llama "imdbnumber" al id de TMDB. Se conserva tal cual (setIMDBNumber) porque su menú contextual
        # ("Añadir a favoritos"...) lo lee del elemento; y además como uniqueid "tmdb" para la skin.
        tag.setIMDBNumber(str(f["imdbnumber"]))
        tag.setUniqueIDs({"tmdb": str(f["imdbnumber"])}, "tmdb")
    if f.get("originaltitle"):
        tag.setOriginalTitle(f["originaltitle"])
    if f.get("tagline"):
        tag.setTagLine(f["tagline"])
    if f.get("studio"):
        tag.setStudios(list(f["studio"]))
    if f.get("country"):
        tag.setCountries(list(f["country"]))
    if f.get("director"):
        tag.setDirectors(list(f["director"]))
    art = {k: v for k, v in (f.get("art") or {}).items() if v}
    if generic and not art.get("poster"):  # otros add-ons: sin cartel, vale la miniatura
        thumb = art.get("thumb") or art.get("icon") or art.get("landscape")
        if thumb:
            art["poster"] = thumb
    if art:
        li.setArt(art)
    if not isdir:
        li.setProperty("IsPlayable", "true")
    return f["file"], li, isdir


SEARCH_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s/searchcache/" % SKIN_ID)


def search_results(handle, params):
    """?mode=results&t=<token>&cat=<n>: contenido de la categoría n de una búsqueda (ver skincat_search.py)."""
    token = re.sub(r"[^0-9a-f]", "", params.get("t", ""))
    try:
        cat = int(params.get("cat", "0"))
        with open(os.path.join(SEARCH_DIR, token + ".json"), "r", encoding="utf-8") as f:
            cats = json.load(f)
        label, path = cats[cat - 1]["label"], cats[cat - 1]["file"]
    except (ValueError, OSError, IndexError, KeyError):
        xbmcplugin.endOfDirectory(handle)  # sin búsqueda activa: lista vacía
        return
    entries = []
    try:
        for _ in range(4):
            nxt = None
            files = get_page(path)
            for f in files:
                if is_search(f):
                    continue
                if is_more(f):
                    nxt = f["file"]
                else:
                    entries.append(make_item(f))
            if nxt is None:
                break
            path = nxt
        if files and not any(is_title(f) for f in files):
            entries = []
            flatten(files, entries)
            if not entries:
                entries.append(note_item("Sin resultados en esta categoría"))
    except Exception as e:
        log("error en resultados: %r" % e)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    xbmcplugin.setPluginCategory(handle, label)
    for _path, li, _isdir in entries:  # Kodi no expone la categoría del plugin a la skin: va en cada elemento
        li.setProperty("skincat_cat", label)
    xbmcplugin.setContent(handle, "movies")
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


def pick_is_palantir(src):
    return src.startswith("plugin://plugin.video.palantir3")


def main():
    handle = int(sys.argv[1])
    qs = (sys.argv[2] if len(sys.argv) > 2 else "")[1:]
    if qs.startswith("mode=results"):
        search_results(handle, dict(p.split("=", 1) for p in qs.split("&") if "=" in p))
        return
    head, sep, src = qs.partition("src=")
    params = dict(p.split("=", 1) for p in head.split("&") if "=" in p)
    if params.get("mode") == "sheet" and src:
        sheet(handle, src, params.get("season", ""))
        return
    if params.get("mode") == "seasons" and src:
        sheet_seasons(handle, src, params.get("sel", ""))
        return
    if not sep or not src:  # fila sin configurar: lista vacía (sin error en el log)
        xbmcplugin.endOfDirectory(handle)
        return
    if src and params.get("mode") not in ("pick", "sheet", "seasons"):
        log("carga de fila: pages=%s src=...%s" % (params.get("pages") or "1", src[-18:]))
    if src.rstrip("/") == FAV_PATH and params.get("mode") != "pick":
        favourites(handle)
        return
    if src.rstrip("/") == watch.CONT_PATH:
        continue_row(handle)
        return
    if src.rstrip("/") == ADDONS_PATH:  # en el selector y en la fila: la misma lista de add-ons
        video_addons(handle)
        return
    pick = params.get("mode") == "pick"  # selector de filas: 1 página, sin "Cargar más"
    if pick and src.rstrip("/") == FAV_PATH:  # selector: dentro de "Favoritos de Kodi" solo hay una opción
        li = xbmcgui.ListItem("Todos mis favoritos")
        xbmcplugin.addDirectoryItems(handle, [(FAV_PATH, li, True)], 1)
        xbmcplugin.endOfDirectory(handle)
        return
    if not pick_is_palantir(src):  # cualquier otro add-on de vídeo
        generic_row(handle, src)
        return
    sort = params.get("sort") if params.get("sort") in ("yd", "ya", "az") and not pick else ""
    pages = 1 if pick else (SORT_PAGES if sort else max(1, min(int(params.get("pages") or 1), MAX_PAGES)))
    path = src
    entries = []
    more_left = False
    try:
        for page in range(1, pages + 1):
            files = get_page(path)
            nxt = None
            if not pick and page == 1 and files and not any(is_title(f) for f in files):
                flatten(files, entries)
                if not entries:
                    entries.append(note_item("Aún no hay títulos aquí"))
                elif sort:
                    entries = sort_entries(entries, sort)
                break
            for f in files:
                if is_search(f):
                    # raíz: se descarta solo el elemento; dentro de una categoría "Buscar:" abre un bloque de
                    # búsquedas que ocupa el resto de la lista, así que se corta ahí
                    if f.get("filetype") == "file":
                        break
                    continue
                if is_more(f):
                    nxt = f["file"]
                else:
                    entries.append(make_item(f))
            if nxt is None:
                more_left = False
                break
            path, more_left = nxt, True
    except Exception as e:
        log("error: %r" % e)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    if sort and entries and not any(e[1].getProperty("skincat_tile") for e in entries[:1]):
        entries = sort_entries(entries, sort)
        log("ordenada por %s: %d títulos%s" % (sort, len(entries), " (hay más páginas sin cargar)" if more_left else ""))
        more_left = False  # con un orden activo no hay "Cargar más": se ha cargado todo lo razonable de una vez
    if pick and src.rstrip("/") == ROOT_URL.rstrip("/"):
        entries.insert(0, favourites_category())
        entries.append(addons_category())
    if more_left and not pick:
        li = xbmcgui.ListItem("+ Cargar más")
        li.setProperty("skincat_more", "1")
        li.setProperty("skincat_tile", "1")
        li.setProperty("next_pages", str(pages + 1))
        li.setProperty("focus_index", str(len(entries)))
        entries.append(("plugin://%s/?more=1" % SKIN_ID, li, False))
    xbmcplugin.setContent(handle, "movies")
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addDirectoryItems(handle, entries, len(entries))
    xbmcplugin.endOfDirectory(handle)


main()
