# -*- coding: utf-8 -*-
"""SkinCat: "Ver capítulos" en el menú contextual (pulsación larga en OK) de la fila "Continuar viendo".

Lo lanza el primer botón fijo de DialogContextMenu.xml, visible solo en los elementos con la propiedad skincat_eps (capítulos de
una serie; los pone scripts/skincat_rows.py y el servicio publica su serie en SkinCat.Focus.EpsSrc). Abre la hoja lateral de capítulos (Custom_1114_Sheet.xml) de esa serie, igual que al pulsar
una serie en una fila: Skin.SetString(sheet_src) + ActivateWindow(1114).
"""
import sys

import xbmc

li = getattr(sys, "listitem", None)
src = xbmc.getInfoLabel("Window(Home).Property(SkinCat.Focus.EpsSrc)") or (li.getProperty("showsrc") if li else "")
if src:
    xbmc.executebuiltin("Skin.Reset(sheet_season)")
    xbmc.executebuiltin('Skin.SetString(sheet_src,"%s")' % src.replace('"', "%22"))
    xbmc.executebuiltin("ActivateWindow(1114)")
