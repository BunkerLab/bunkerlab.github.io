# -*- coding: utf-8 -*-
"""SkinCat: "Ver capítulos" en el menú contextual (pulsación larga en OK) de la fila "Continuar viendo".

Lo registra addon.xml con kodi.context.item, visible solo en los elementos con la propiedad skincat_eps (capítulos de una serie,
los pone scripts/skincat_rows.py). Abre la hoja lateral de capítulos (Custom_1114_Sheet.xml) de esa serie, igual que al pulsar
una serie en una fila: Skin.SetString(sheet_src) + ActivateWindow(1114).
"""
import sys

import xbmc

li = getattr(sys, "listitem", None)
src = (li.getProperty("showsrc") if li else "") or xbmc.getInfoLabel("ListItem.Property(showsrc)")
if src:
    xbmc.executebuiltin("Skin.Reset(sheet_season)")
    xbmc.executebuiltin('Skin.SetString(sheet_src,"%s")' % src.replace('"', "%22"))
    xbmc.executebuiltin("ActivateWindow(1114)")
