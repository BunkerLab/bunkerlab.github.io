# -*- coding: utf-8 -*-
"""SkinCat: herramientas para las filas del Home.

  RunScript(special://skin/scripts/skincat_rowtools.py,remove)
      Quita la fila indicada en Skin.String(picker_row) y sube todas las siguientes un puesto, sin dejar huecos.
      (Skin.SetString con un valor vacío abriría el teclado de Kodi, por eso se usa Skin.Reset para las filas vacías.)
"""
import sys
import xbmc

MAX_ROWS = 24  # igual que devtools/gen_rows.py
FIELDS = ("path", "title", "pages")


def get(n, field):
    return xbmc.getInfoLabel("Skin.String(widget%d%s)" % (n, field))


def put(n, field, value):
    name = "widget%d%s" % (n, field)
    if value:
        xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (name, value.replace('"', "'")))
    else:
        xbmc.executebuiltin("Skin.Reset(%s)" % name)


def remove():
    row = xbmc.getInfoLabel("Skin.String(picker_row)")
    if not row.isdigit() or not 1 <= int(row) <= MAX_ROWS:
        return
    row = int(row)
    for n in range(row, MAX_ROWS):          # la fila n pasa a ser la n+1
        for f in FIELDS:
            put(n, f, get(n + 1, f))
    for f in FIELDS:                        # la última queda vacía
        put(MAX_ROWS, f, "")


if len(sys.argv) > 1 and sys.argv[1] == "remove":
    remove()
