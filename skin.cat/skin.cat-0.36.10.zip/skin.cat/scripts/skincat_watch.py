# -*- coding: utf-8 -*-
"""SkinCat: historial de "Continuar viendo" (películas a medias y series en curso).

Lo usan dos procesos: el servicio (skincat_imdb.py) que sigue la reproducción, y el plugin interno (skincat_rows.py)
que dibuja la fila 0. Comparten un SQLite (addon_data/skin.cat/watching.db).

Cómo se sabe qué se está viendo: al pulsar OK en un título/capítulo, la skin deja en Window(Home) unas propiedades
(SkinCat.Play.Path/Src/Season/Episode/Resume). Cuando Kodi arranca la reproducción (onAVStarted) el servicio las lee,
completa la ficha con la memoria de títulos (itemmeta.db) y la guarda. Mientras se reproduce guarda la posición cada 5 s.
  * Película: se queda en la fila con barra de progreso hasta verla (>= 92 %); entonces desaparece.
  * Serie: una sola entrada por serie. Si el capítulo no se terminó se reanuda en el mismo punto; si se terminó, la
    fila muestra el capítulo siguiente (lo resuelve el plugin con el listado de Palantir).
  * Si se para antes de 60 s de un título nuevo no se guarda nada (fue un vistazo).
Solo se registra lo que se reproduce desde la skin (filas, hoja de capítulos y la propia fila 0).
"""
import json
import os
import re
import sqlite3
import time

import xbmc
import xbmcvfs

SKIN_ID = "skin.cat"
DB_PATH = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID), "watching.db")
CONT_PATH = "skincat://continue"
DONE_AT = 0.92      # fracción vista a partir de la cual cuenta como terminado
MIN_SECONDS = 60    # menos que esto = vistazo, no se guarda
MAX_ENTRIES = 30
TAGS = re.compile(r"\[/?(?:COLOR[^\]]*|B|I|CR)\]", re.I)

COLS = ("key", "kind", "title", "show", "showsrc", "season", "episode", "path", "label", "poster", "thumb", "fanart",
        "plot", "tmdb", "year", "pos", "total", "updated", "done")


def _con():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("CREATE TABLE IF NOT EXISTS cont (key TEXT PRIMARY KEY, kind TEXT, title TEXT, show TEXT, showsrc TEXT,"
                " season INT, episode INT, path TEXT, label TEXT, poster TEXT, thumb TEXT, fanart TEXT, plot TEXT,"
                " tmdb TEXT, year TEXT, pos REAL, total REAL, updated REAL, done INT)")
    return con


def count():
    try:
        con = _con()
        n = con.execute("SELECT COUNT(*) FROM cont").fetchone()[0]
        con.close()
        return n
    except sqlite3.Error:
        return 0


def entries():
    """Más reciente primero."""
    try:
        con = _con()
        rows = [dict(r) for r in con.execute("SELECT * FROM cont ORDER BY updated DESC LIMIT ?", (MAX_ENTRIES,))]
        con.close()
        return rows
    except sqlite3.Error:
        return []


def get(key):
    try:
        con = _con()
        r = con.execute("SELECT * FROM cont WHERE key=?", (key,)).fetchone()
        con.close()
        return dict(r) if r else None
    except sqlite3.Error:
        return None


def put(e):
    e = dict(e)
    e.setdefault("updated", time.time())
    try:
        con = _con()
        con.execute("INSERT OR REPLACE INTO cont (%s) VALUES (%s)" % (",".join(COLS), ",".join("?" * len(COLS))),
                    [e.get(c) for c in COLS])
        n = con.execute("SELECT COUNT(*) FROM cont").fetchone()[0]
        if n > MAX_ENTRIES * 2:
            con.execute("DELETE FROM cont WHERE key IN (SELECT key FROM cont ORDER BY updated ASC LIMIT ?)", (n - MAX_ENTRIES,))
        con.commit()
        con.close()
    except sqlite3.Error as ex:
        xbmc.log("[SkinCat watch] put: %r" % ex, xbmc.LOGINFO)


def delete(key):
    try:
        con = _con()
        con.execute("DELETE FROM cont WHERE key=?", (key,))
        con.commit()
        con.close()
    except sqlite3.Error:
        pass


def clean(s):
    return TAGS.sub("", s or "").strip()


def strip_year(s):
    return re.sub(r"\s*\(\d{4}\)\s*$", "", clean(s)).strip()


def title_key(label):
    t = re.sub(r"\[[^\]]*\]", "", label or "")
    return re.sub(r"\s+", " ", t).strip().lower()


def show_key(tmdb, show):
    return "tv:" + (str(tmdb) if tmdb else title_key(show))


def meta(path, label=""):
    """Ficha guardada por el plugin interno (itemmeta.db), por ruta o por nombre."""
    try:
        con = sqlite3.connect(os.path.join(os.path.dirname(DB_PATH), "itemmeta.db"), timeout=10)
        row = con.execute("SELECT json FROM meta WHERE path=?", (path,)).fetchone() if path else None
        if not row and label:
            row = con.execute("SELECT json FROM bytitle WHERE tkey=?", (title_key(label),)).fetchone()
        con.close()
        return json.loads(row[0]) if row else None
    except (sqlite3.Error, ValueError):
        return None


def _art(m, *names):
    art = (m or {}).get("art") or {}
    for n in names:
        if art.get(n):
            return art[n]
    return ""


# ------------------------------------------------------------------ seguimiento de la reproducción (servicio)
class Tracker(xbmc.Player):
    def __init__(self, win):
        super().__init__()
        self.win = win
        self.cur = None   # entrada que se está viendo (dict) o None
        self.prev = None  # lo que había antes de empezar (para deshacer los vistazos)

    # --- eventos
    def onAVStarted(self):
        w = self.win
        path = w.getProperty("SkinCat.Play.Path")
        if not path:
            self.cur = None
            return
        if "plugin.video.palantir3" not in path:  # solo se sigue lo de Palantir (otros add-ons no entran en "Continuar viendo")
            for k in ("Path", "Src", "Season", "Episode", "Resume"):
                w.clearProperty("SkinCat.Play." + k)
            self.cur = None
            return
        src = w.getProperty("SkinCat.Play.Src")
        season = w.getProperty("SkinCat.Play.Season")
        episode = w.getProperty("SkinCat.Play.Episode")
        resume = w.getProperty("SkinCat.Play.Resume")
        for k in ("Path", "Src", "Season", "Episode", "Resume"):
            w.clearProperty("SkinCat.Play." + k)
        try:
            self.cur = self._entry(path, src, season, episode)
        except Exception as ex:
            xbmc.log("[SkinCat watch] no se pudo registrar: %r" % ex, xbmc.LOGINFO)
            self.cur = None
            return
        self.prev = get(self.cur["key"])
        try:
            r = float(resume)
        except ValueError:
            r = 0.0
        if r > 0:
            self.cur["pos"] = r
            import threading
            threading.Timer(2.0, self._seek, args=(r,)).start()
        self.cur["updated"] = time.time()
        put(self.cur)
        xbmc.log("[SkinCat watch] viendo: %s (%s)" % (self.cur.get("label"), self.cur["key"]), xbmc.LOGINFO)

    def _seek(self, secs):
        try:
            if self.isPlayingVideo():
                self.seekTime(secs)
        except Exception:
            pass

    def onPlayBackEnded(self):
        self._finish(True)

    def onPlayBackStopped(self):
        self._finish(False)

    def onPlayBackError(self):
        self.cur = None

    # --- utilidades
    def _entry(self, path, src, season, episode):
        m = meta(path) or {}
        label = clean(m.get("label")) or ""
        if src:  # capítulo de una serie
            sm = meta(src) or {}
            show = strip_year(sm.get("label") or "")
            tmdb = sm.get("imdbnumber") or m.get("imdbnumber") or ""
            s = int(season) if season.isdigit() else int(m.get("season") or 0)
            e = int(episode) if episode.isdigit() else int(m.get("episode") or 0)
            return {"key": show_key(tmdb, show), "kind": "episode", "title": label, "show": show, "showsrc": src,
                    "season": s, "episode": e, "path": path, "label": label,
                    "poster": _art(sm, "poster", "thumb") or _art(m, "poster", "thumb"),
                    "thumb": _art(m, "thumb", "poster"), "fanart": _art(sm, "fanart") or _art(m, "fanart"),
                    "plot": m.get("plot") or "", "tmdb": str(tmdb or ""), "year": str(sm.get("year") or ""),
                    "pos": 0.0, "total": 0.0, "done": 0}
        tag = self.getVideoInfoTag()
        title = strip_year(label) or tag.getTitle() or "Sin título"
        tmdb = m.get("imdbnumber") or ""
        return {"key": "mv:" + (str(tmdb) if tmdb else title_key(title)), "kind": "movie", "title": title,
                "show": "", "showsrc": "", "season": 0, "episode": 0, "path": path, "label": title,
                "poster": _art(m, "poster", "thumb"), "thumb": _art(m, "thumb", "poster"), "fanart": _art(m, "fanart"),
                "plot": m.get("plot") or "", "tmdb": str(tmdb), "year": str(m.get("year") or ""),
                "pos": 0.0, "total": 0.0, "done": 0}

    def poll(self):
        """Cada ~5 s: guarda la posición."""
        if not self.cur:
            return
        try:
            if not self.isPlayingVideo():
                return
            pos, total = self.getTime(), self.getTotalTime()
        except Exception:
            return
        if total > 0:
            self.cur["pos"], self.cur["total"] = pos, total
            self.cur["updated"] = time.time()
            put(self.cur)

    def _finish(self, ended):
        e, prev = self.cur, self.prev
        self.cur = self.prev = None
        if not e:
            return
        pos, total = e.get("pos") or 0.0, e.get("total") or 0.0
        watched = ended or (total > 0 and pos / total >= DONE_AT)
        if watched:
            if e["kind"] == "movie":
                delete(e["key"])
                xbmc.log("[SkinCat watch] película terminada: %s" % e["label"], xbmc.LOGINFO)
            else:
                e["done"], e["pos"], e["updated"] = 1, 0.0, time.time()
                put(e)
                xbmc.log("[SkinCat watch] capítulo terminado: %s" % e["label"], xbmc.LOGINFO)
        elif pos < MIN_SECONDS and not (prev and (prev.get("pos") or 0) >= MIN_SECONDS and prev.get("path") == e["path"]):
            if prev:
                put(prev)
            else:
                delete(e["key"])  # un vistazo de menos de un minuto
        else:
            e["updated"] = time.time()
            put(e)
