# -*- coding: utf-8 -*-
"""SkinCat: búsqueda en Palantir sin salir de la skin.

Lo lanza Custom_1113_Search.xml (<onload>, solo si la lupa puso SkinCat.Search.Ask=1) y el botón "nueva búsqueda".
Pide el texto con el teclado de Kodi y lo guarda en SkinCat.Search.Query.

Cómo funciona (sin tocar el código de Palantir, usándolo como lo haría un usuario):
  1. Busca en la raíz de Palantir la carpeta "Buscar por título" y la abre (Files.GetDirectory).
     Palantir muestra su teclado virtual; este script lo detecta y le envía el texto (Input.SendText, done).
  2. Palantir devuelve una carpeta por categoría con resultados: "Películas (8)", "Series (2)", ...
     Se guardan (caché 10 min) y se publican en Window(Home):
        SkinCat.Search.Status = searching | ok | empty | error
        SkinCat.Search.Count  = nº de categorías con resultados
        SkinCat.Search.Token  = id de esta búsqueda (las filas de resultados cargan con él)
  3. Las filas de la ventana de búsqueda leen cada categoría con
        plugin://skin.cat/?mode=results&t=<token>&cat=<n>
"""
import hashlib
import html
import json
import os
import re
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import xbmc
import xbmcgui
import xbmcvfs

import skincat_qr

SKIN_ID = "skin.cat"
ROOT = "plugin://plugin.video.palantir3/"
CACHE_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s/searchcache/" % SKIN_ID)
CACHE_TTL = 10 * 60
TAGS = re.compile(r"\[/?(?:COLOR[^\]]*|B|I|CR)\]", re.I)
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID)
LOGO_FILE = xbmcvfs.translatePath("special://skin/media/logo-skincat-completo.png")
PHONE_PORTS = range(8765, 8776)
PHONE_MAX_CHARS = 120
win = xbmcgui.Window(10000)


def log(msg):
    xbmc.log("[SkinCat search] %s" % msg, xbmc.LOGINFO)


def jsonrpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def clean(label):
    return TAGS.sub("", label or "").strip()


def cache_file(token):
    return os.path.join(CACHE_DIR, token + ".json")


def feed_keyboard(query, stop):
    """Espera a que Palantir abra su teclado virtual y le escribe el texto."""
    t0 = time.time()
    while not stop.is_set() and time.time() - t0 < 10:
        if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
            time.sleep(0.4)
            jsonrpc("Input.SendText", {"text": query, "done": True})
            return
        time.sleep(0.1)


def run_search(query):
    root = jsonrpc("Files.GetDirectory", {"directory": ROOT, "media": "video"}).get("result", {}).get("files", [])
    entry = next((f for f in root if f.get("filetype") == "directory" and clean(f.get("label")).lower().startswith("buscar")), None)
    if not entry:
        raise RuntimeError("no se encontró la carpeta de búsqueda de Palantir")
    stop = threading.Event()
    t = threading.Thread(target=feed_keyboard, args=(query, stop), daemon=True)
    t.start()
    try:
        res = jsonrpc("Files.GetDirectory", {"directory": entry["file"], "media": "video"})
    finally:
        stop.set()
    files = res.get("result", {}).get("files")
    if files is None:  # Palantir devuelve error cuando no hay resultados o se cancela el teclado
        return []
    return [{"label": f["label"], "file": f["file"]} for f in files
            if f.get("filetype") == "directory" and not clean(f.get("label")).lower().startswith("buscar")]


# ------------------------------------------------------------------ escribir con el móvil (QR + mini servidor web)
PAGE = """<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SkinCat · Buscar</title>
<style>
 :root{color-scheme:dark}
 body{margin:0;background:#090b10;color:#fff;font:18px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
      min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;box-sizing:border-box}
 img.logo{width:min(70vw,320px);height:auto;margin-bottom:28px}
 form{width:100%;max-width:560px}
 label{display:block;color:#9a9aa0;margin-bottom:10px}
 input[type=search]{width:100%;box-sizing:border-box;font-size:26px;padding:18px 16px;border-radius:10px;border:2px solid #2a2a2e;
      background:#16161a;color:#fff;outline:none}
 input[type=search]:focus{border-color:#f5c518}
 button{margin-top:16px;width:100%;font-size:22px;padding:16px;border:0;border-radius:10px;background:#fff;color:#141414;font-weight:600}
 .ok{color:#9be07f;font-size:24px;text-align:center}
 a.btn{display:block;box-sizing:border-box;margin:22px auto 0;width:100%;max-width:560px;text-align:center;text-decoration:none;
      font-size:22px;padding:16px;border-radius:10px;background:#fff;color:#141414;font-weight:600}
 .muted{color:#9a9aa0;text-align:center;margin-top:10px}
</style></head><body>
<img class="logo" src="/logo.png" alt="SkinCat">
@@BODY@@
</body></html>"""

FORM = """<form method="post" action="/q?t=%s">
<label for="q">¿Qué quieres ver?</label>
<input id="q" name="q" type="search" maxlength="%d" enterkeyhint="search" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" autofocus>
<button type="submit">Buscar</button>
</form>"""

def sent_page(q, token):
    return ('<p class="ok">✓ Enviado</p><p class="muted">«%s»<br>Mira la tele.</p>'
            '<a class="btn" href="/?t=%s">Buscar otra</a>') % (html.escape(q), html.escape(token))


class PhoneInput:
    """Servidor web mínimo y efímero: vive mientras la ventana del QR está abierta y, después, mientras la ventana de
    resultados de búsqueda siga abierta (así el móvil puede pedir otra búsqueda con "Buscar otra"). Protegido por un código
    aleatorio en la dirección; acepta únicamente un texto corto por POST /q y sirve el logo de la skin."""

    def __init__(self):
        self.token = secrets.token_urlsafe(6)[:8]
        self.text = None
        self.httpd = None
        self.port = 0

    def start(self):
        outer = self

        class Handler(BaseHTTPRequestHandler):
            timeout = 10

            def log_message(self, *args):
                pass

            def _send(self, code, body, ctype="text/html; charset=utf-8"):
                data = body if isinstance(body, bytes) else body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)

            def _authorized(self, url):
                return parse_qs(url.query).get("t", [""])[0] == outer.token

            def do_GET(self):
                url = urlparse(self.path)
                if url.path == "/logo.png":
                    try:
                        with open(LOGO_FILE, "rb") as f:
                            self._send(200, f.read(), "image/png")
                    except OSError:
                        self._send(404, "")
                    return
                if url.path != "/" or not self._authorized(url):
                    self._send(403, "Código no válido. Escanea el QR de la tele.", "text/plain; charset=utf-8")
                    return
                self._send(200, PAGE.replace("@@BODY@@", FORM % (html.escape(outer.token), PHONE_MAX_CHARS)))

            def do_POST(self):
                url = urlparse(self.path)
                if url.path != "/q" or not self._authorized(url):
                    self._send(403, "Código no válido.", "text/plain; charset=utf-8")
                    return
                try:
                    size = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    size = 0
                if not 0 < size <= 2048:
                    self._send(400, "Petición no válida.", "text/plain; charset=utf-8")
                    return
                q = parse_qs(self.rfile.read(size).decode("utf-8", "replace")).get("q", [""])[0]
                q = " ".join(q.split())[:PHONE_MAX_CHARS]
                if not q:
                    self._send(200, PAGE.replace("@@BODY@@", FORM % (html.escape(outer.token), PHONE_MAX_CHARS)))
                    return
                outer.text = q  # la tele lo recoge (si llegan dos seguidos, gana el último)
                self._send(200, PAGE.replace("@@BODY@@", sent_page(q, outer.token)))

        for port in PHONE_PORTS:
            try:
                self.httpd = ThreadingHTTPServer(("0.0.0.0", port), Handler)
                self.port = port
                break
            except OSError:
                continue
        if self.httpd is None:
            raise OSError("no hay ningún puerto libre para el servidor del móvil")
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def url(self):
        return "http://%s:%d/?t=%s" % (xbmc.getIPAddress(), self.port, self.token)

    def stop(self):
        if self.httpd:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None


def phone_enabled():
    """Ajuste "Buscar con el móvil" (Ajustes de SkinCat > General). Sin tocarlo: activo solo en Android y Fire TV, apagado
    en Mac/PC. search_phone_on / search_phone_off son lo que el usuario fijó a mano."""
    if xbmc.getCondVisibility("Skin.HasSetting(search_phone_off)"):
        return False
    return xbmc.getCondVisibility("Skin.HasSetting(search_phone_on) | System.Platform.Android")


def ask_phone():
    """Abre la ventana con el QR (Custom_1116_Phone.xml) y espera. Devuelve el texto, "" si se cancela o None si hay que
    usar el teclado de siempre (el usuario lo pidió, o no hay red/puerto). Devuelve (resultado, servidor): el servidor solo
    sigue vivo si llegó texto (main lo mantiene mientras se ven los resultados)."""
    ip = xbmc.getIPAddress()
    if not ip or ip.startswith("127."):
        log("sin red local: se usa el teclado")
        return None, None
    srv = PhoneInput()
    try:
        srv.start()
    except OSError as e:
        log("servidor del móvil: %r" % e)
        return None, None
    for name in os.listdir(DATA_DIR) if os.path.isdir(DATA_DIR) else []:
        if name.startswith("phone_qr_"):
            try:
                os.remove(os.path.join(DATA_DIR, name))
            except OSError:
                pass
    qr_path = os.path.join(DATA_DIR, "phone_qr_%s.png" % srv.token)  # nombre nuevo cada vez: Kodi cachea las texturas por ruta
    result = ""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        skincat_qr.save_png(qr_path, skincat_qr.make(srv.url()), scale=12, border=4)
        win.setProperty("SkinCat.Phone.URL", srv.url())
        win.setProperty("SkinCat.Phone.QR", qr_path)
        win.clearProperty("SkinCat.Phone.Keyboard")
        log("esperando texto del móvil en %s" % srv.url())
        xbmc.executebuiltin("ActivateWindow(1116)")
        monitor = xbmc.Monitor()
        seen, t0 = False, time.time()
        while not monitor.abortRequested():
            if srv.text is not None:
                result = srv.text
                log("texto recibido del móvil: %r" % result)
                break
            opened = xbmc.getCondVisibility("Window.IsActive(1116)")
            seen = seen or opened
            if win.getProperty("SkinCat.Phone.Keyboard") == "1":
                result = None
                break
            if (seen and not opened) or (not seen and time.time() - t0 > 4):
                result = ""  # cerró la ventana (Atrás)
                break
            monitor.waitForAbort(0.15)
    except Exception as e:
        log("error en la ventana del móvil: %r" % e)
        result = None
    finally:
        if not result:
            srv.stop()
        xbmc.executebuiltin("Dialog.Close(1116)")
        for p in ("URL", "QR", "Keyboard"):
            win.clearProperty("SkinCat.Phone." + p)
        try:
            os.remove(qr_path)
        except OSError:
            pass
    if result is None:
        time.sleep(0.4)  # deja terminar de cerrarse el diálogo antes de abrir el teclado
    return result, (srv if result else None)


def ask_keyboard():
    """Teclado de Kodi (con el aspecto de la skin). Devuelve el texto o '' si se cancela."""
    kb = xbmc.Keyboard(win.getProperty("SkinCat.Search.Query"), "Buscar en Palantir")
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else ""


def ask_query():
    """Devuelve (texto, servidor del móvil o None)."""
    if phone_enabled():
        q, srv = ask_phone()
        if q is not None:
            return q, srv
    return ask_keyboard(), None


def do_search(query):
    win.setProperty("SkinCat.Search.Query", query)
    token = hashlib.md5(query.lower().encode("utf-8")).hexdigest()[:12]
    for p in ("Token", "Count"):
        win.clearProperty("SkinCat.Search." + p)
    win.setProperty("SkinCat.Search.Status", "searching")
    os.makedirs(CACHE_DIR, exist_ok=True)
    cats = None
    cf = cache_file(token)
    try:
        if time.time() - os.path.getmtime(cf) < CACHE_TTL:
            with open(cf, "r", encoding="utf-8") as f:
                cats = json.load(f)
    except (OSError, ValueError):
        pass
    try:
        if cats is None:
            log("buscando %r" % query)
            cats = run_search(query)
            if cats:
                with open(cf, "w", encoding="utf-8") as f:
                    json.dump(cats, f)
        log("%d categorías con resultados" % len(cats))
    except Exception as e:
        log("error: %r" % e)
        win.setProperty("SkinCat.Search.Status", "error")
        return
    if not cats:
        win.setProperty("SkinCat.Search.Status", "empty")
        return
    win.setProperty("SkinCat.Search.Count", str(len(cats)))
    win.setProperty("SkinCat.Search.Token", token)
    win.setProperty("SkinCat.Search.Status", "ok")
    # cuando las filas hayan cargado, llevar el foco a la primera
    for _ in range(40):
        time.sleep(0.25)
        if xbmc.getCondVisibility("Window.IsActive(1113)") and xbmc.getInfoLabel("Container(9211).NumItems") not in ("", "0"):
            xbmc.executebuiltin("SetFocus(9211)")
            break



def wait_phone_text(srv, me):
    """Con los resultados en pantalla, espera otro texto del móvil ("Buscar otra"). Termina (None) al salir de la ventana de
    búsqueda, si otra instancia de este script toma el relevo o si Kodi se cierra."""
    monitor, away = xbmc.Monitor(), None
    while not monitor.abortRequested():
        if win.getProperty("SkinCat.Search.Instance") != me:
            return None
        if srv.text is not None:
            text, srv.text = srv.text, None
            log("otro texto del móvil: %r" % text)
            return text
        if xbmc.getCondVisibility("Window.IsActive(1113)"):
            away = None
        else:
            away = away or time.time()
            if time.time() - away > 4:
                return None
        monitor.waitForAbort(0.2)
    return None


def main():
    ask = win.getProperty("SkinCat.Search.Ask") == "1" or "ask" in sys.argv[1:]
    win.clearProperty("SkinCat.Search.Ask")
    if not ask:  # onload al volver de otra ventana (p. ej. tras abrir una carpeta): no repetir la búsqueda
        return
    me = secrets.token_hex(4)
    win.setProperty("SkinCat.Search.Instance", me)  # si ya había otra búsqueda esperando al móvil, se retira
    query, srv = ask_query()
    try:
        while True:
            if not query:
                if xbmc.getCondVisibility("Window.IsActive(1113)") and not win.getProperty("SkinCat.Search.Token"):
                    xbmc.executebuiltin("Action(PreviousMenu)")  # canceló la primera búsqueda: volver al Home
                break
            do_search(query)
            if srv is None:
                break
            query = wait_phone_text(srv, me)
            if query is None:
                break
    finally:
        if srv:
            srv.stop()
            log("servidor del móvil apagado")


if __name__ == "__main__":
    main()
