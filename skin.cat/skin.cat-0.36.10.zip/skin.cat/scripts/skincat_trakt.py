# -*- coding: utf-8 -*-
"""SkinCat: sugerencias de listas de Trakt para el selector de filas.

Dos usos:
  * como módulo (lo importa scripts/skincat_rows.py): consulta la API pública de Trakt (listas populares, en tendencia y búsqueda
    por palabra) y devuelve datos de las listas. Solo necesita un Client ID (cabecera trakt-api-key): no hay inicio de sesión.
    La clave se guarda en addon_data/skin.cat/trakt_key.txt (Ajustes de SkinCat > Clave de Trakt). NO va dentro de la skin.
  * como script (RunScript(special://skin/scripts/skincat_trakt.py,<acción>)):
        ask   pide una palabra (con el móvil si procede, si no con el teclado) y la guarda en Skin.String(trakt_query)
        add   añade la lista enfocada a Palantir (su carpeta "Listas Trakt.tv" > "Añadir lista nueva...", que pide el código o la
              dirección de la lista) y la deja como contenido de la fila Skin.String(picker_row)

El contenido de una lista de Trakt lo sirve Palantir: solo aparecen los títulos que Palantir tenga.
"""
import hashlib
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcvfs

SKIN_ID = "skin.cat"
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID)
KEY_PATH = os.path.join(DATA_DIR, "trakt_key.txt")
CACHE_DIR = os.path.join(DATA_DIR, "traktcache")
CACHE_TTL = 15 * 60
API = "https://api.trakt.tv/"
ROOT = "plugin://plugin.video.palantir3/"
TAGS = re.compile(r"\[/?(?:COLOR[^\]]*|B|I|CR)\]", re.I)
LIMIT = 14


def log(msg):
    xbmc.log("[SkinCat trakt] %s" % msg, xbmc.LOGINFO)


def api_key():
    try:
        with open(KEY_PATH, "r") as f:
            return f.read().strip()
    except OSError:
        return ""


def _get(path, params):
    key = api_key()
    if not key:
        raise RuntimeError("sin Client ID de Trakt")
    url = API + path + "?" + urllib.parse.urlencode(params)
    cf = os.path.join(CACHE_DIR, hashlib.md5(url.encode("utf-8")).hexdigest() + ".json")
    try:
        if time.time() - os.path.getmtime(cf) < CACHE_TTL:
            with open(cf, "r", encoding="utf-8") as f:
                return json.load(f)
    except (OSError, ValueError):
        pass
    req = urllib.request.Request(url, headers={"Content-Type": "application/json", "trakt-api-version": "2", "trakt-api-key": key,
                                               "User-Agent": "SkinCat-Kodi/1.0"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.loads(r.read().decode("utf-8"))
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        with open(cf, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except OSError:
        pass
    return data


def _simplify(entry):
    """Una entrada de Trakt ({"list": {...}} o la lista a secas) -> dict plano con lo que enseña el selector."""
    lst = entry.get("list", entry)
    user = lst.get("user") or {}
    uslug = (user.get("ids") or {}).get("slug") or user.get("username") or ""
    lslug = (lst.get("ids") or {}).get("slug") or ""
    if not (lst.get("name") and uslug and lslug):
        return None
    return {"name": TAGS.sub("", lst["name"]).strip(), "items": lst.get("item_count") or 0, "likes": lst.get("likes") or entry.get("like_count") or 0,
            "user": user.get("username") or uslug, "url": "https://trakt.tv/users/%s/lists/%s" % (uslug, lslug),
            "desc": (lst.get("description") or "").strip()}


def _lists(path, params):
    out = []
    for e in _get(path, params):
        s = _simplify(e)
        if s and s["items"] > 0:
            out.append(s)
    return out


def popular():
    return _lists("lists/popular", {"limit": LIMIT})


def trending():
    return _lists("lists/trending", {"limit": LIMIT})


def search(query):
    return _lists("search/list", {"query": query, "limit": LIMIT + 6})


# ------------------------------------------------------------------ acciones (RunScript)
def jsonrpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def clean(s):
    return TAGS.sub("", s or "").strip()


def palantir_trakt_folder():
    root = jsonrpc("Files.GetDirectory", {"directory": ROOT, "media": "video"}).get("result", {}).get("files") or []
    return next((f["file"] for f in root if f.get("filetype") == "directory" and "trakt" in clean(f.get("label")).lower()), None)


def folder_entries(path):
    res = jsonrpc("Files.GetDirectory", {"directory": path, "media": "video"})
    return [(clean(f.get("label")), f["file"]) for f in res.get("result", {}).get("files") or []]


DRYRUN_FLAG = os.path.join(DATA_DIR, "trakt_dryrun")  # solo lo crean las pruebas: recorre el camino pero CANCELA el teclado de Palantir


def feed_keyboard(text, stop):
    t0 = time.time()
    while not stop.is_set() and time.time() - t0 < 15:
        if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
            time.sleep(0.5)
            if os.path.exists(DRYRUN_FLAG):
                log("ensayo: teclado de Palantir abierto; se cancela sin escribir %s" % text)
                jsonrpc("Input.Back", {})
            else:
                jsonrpc("Input.SendText", {"text": text, "done": True})
            return
        time.sleep(0.1)


def notify(msg, secs=4000):
    xbmcgui.Dialog().notification("SkinCat", msg, xbmcgui.NOTIFICATION_INFO, secs)


def action_ask():
    import skincat_search as srch  # reutiliza el QR del móvil y el teclado de la búsqueda
    query = ""
    srv = None
    try:
        if srch.phone_enabled():
            q, srv = srch.ask_phone()
            if q is not None:
                query = q
            else:
                query = srch.ask_keyboard()
        else:
            query = srch.ask_keyboard()
    finally:
        if srv:
            srv.stop()
    query = (query or "").strip()
    if not query:
        return
    xbmc.executebuiltin('Skin.SetString(trakt_query,"%s")' % query.replace('"', "'"))
    xbmc.sleep(500)
    xbmc.executebuiltin("SetFocus(200)")


def action_add():
    row = xbmc.getInfoLabel("Skin.String(picker_row)")
    url = xbmc.getInfoLabel("Container(200).ListItem.Property(trakt_url)")
    name = xbmc.getInfoLabel("Container(200).ListItem.Property(trakt_name)")
    if not (row.isdigit() and url):
        return
    folder = palantir_trakt_folder()
    if not folder:
        notify("Palantir no tiene 'Listas Trakt.tv'")
        return
    before = folder_entries(folder)
    add = next((p for l, p in before if "añadir" in l.lower()), None)
    if not add:
        notify("No encuentro 'Añadir lista nueva...' en Palantir")
        return
    xbmc.executebuiltin("Dialog.Close(1111)")
    notify("Añadiendo la lista a Palantir…", 6000)
    stop = threading.Event()
    threading.Thread(target=feed_keyboard, args=(url, stop), daemon=True).start()
    try:
        jsonrpc("Files.GetDirectory", {"directory": add, "media": "video"})  # el resultado no importa: se mira la carpeta después
    finally:
        stop.set()
    xbmc.sleep(800)
    if os.path.exists(DRYRUN_FLAG):
        log("ensayo terminado: no se añadió nada")
        return
    after = folder_entries(folder)
    known = {p for _, p in before}
    new = [(l, p) for l, p in after if p not in known]
    if not new:  # ya estaba añadida, o Palantir no la aceptó: buscarla por nombre
        new = [(l, p) for l, p in after if name and name.lower() in l.lower()]
    if not new:
        log("la lista no aparece en Palantir tras añadirla: %s" % url)
        xbmcgui.Dialog().ok("SkinCat", "Palantir no ha mostrado la lista «%s».[CR]Puede que no la haya aceptado (¿lista privada?) o que no tenga ninguno de sus títulos." % (name or url))
        return
    label, path = new[0]
    title = "Trakt › %s" % (name or label)
    for key, val in (("path", path), ("title", title)):
        xbmc.executebuiltin('Skin.SetString(widget%s%s,"%s")' % (row, key, val.replace('"', "'")))
    for key in ("pages", "sort", "sortlabel"):
        xbmc.executebuiltin("Skin.Reset(widget%s%s)" % (row, key))
    xbmcgui.Window(10000).setProperty("SkinCat.Rows.Rev", str(int(time.time() * 1000)))
    log("lista añadida a la fila %s: %s -> %s" % (row, url, path))
    notify("Lista añadida a la fila %s" % row)
    xbmc.executebuiltin("AlarmClock(refocusrow,SetFocus(902%s),00:01,silent)" % row)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "ask":
        action_ask()
    elif len(sys.argv) > 1 and sys.argv[1] == "add":
        action_add()
