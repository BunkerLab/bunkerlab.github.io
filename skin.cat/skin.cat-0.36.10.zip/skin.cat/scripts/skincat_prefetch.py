# -*- coding: utf-8 -*-
"""SkinCat: reparte las temporadas de la serie del sheet en sus listas (una por temporada) y las va cargando por adelantado.

Lo lanza Custom_1114_Sheet.xml (<onload>). Palantir puede tardar del orden de un minuto en dar cada carpeta en equipos lentos
(Fire TV Stick Lite...) y, además, cada llamada al plugin de Python cuesta más de 1 s en ese equipo aunque los datos estén en caché.
Por eso el sheet tiene UNA LISTA POR TEMPORADA (ids 101-116, ver SkinCatSeasonList en Includes_SkinCat.xml) y cambiar de temporada es
mostrar una y ocultar otra, sin llamar al plugin.

  * La lista 1 (temporada por defecto) la arranca el propio XML en su <onload> (SkinCat.Sheet.Url.1), sin esperar a este script.
  * Este script obtiene los chips (T1, T2..., Esp.), publica SkinCat.Sheet.Count / SkinCat.Sheet.Chip.<k> y después va dando a cada
    lista 2..N su dirección (SkinCat.Sheet.Url.<k>), UNA A UNA: espera a que la lista anterior tenga capítulos antes de pedir la
    siguiente, para no saturar a Palantir (con lo que se carga en orden: temporada 1, 2, 3...).
  * Un solo trabajador a la vez (SkinCat.Prefetch.Running). Si se abre otra serie, gana la última (SkinCat.Prefetch.Src).
  * Mientras el sheet está cerrado Kodi no carga las listas, así que la carga se reanuda al volver a abrirlo (lo ya cargado está
    en la caché de 6 h y tarda poco).
  * Publica SkinCat.Prefetch.Status ("Cargando el resto de temporadas… 2 de 7") para que el sheet lo enseñe.
"""
import json
import re
import time

import xbmc
import xbmcgui

win = xbmcgui.Window(10000)
MAX_SEASONS = 16   # una lista por temporada en el XML (SkinCatSeasonList); las siguientes no tienen lista
LOAD_TIMEOUT = 300


def log(msg):
    xbmc.log("[SkinCat prefetch] %s" % msg, xbmc.LOGINFO)


def rpc(url):
    res = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
                                                     "params": {"directory": url, "media": "video"}})))
    return res.get("result", {}).get("files") or []


def season_chips(src):
    """[(número de temporada, etiqueta del chip)] en el orden del sheet: 1, 2, 3... y Esp. (0) al final. Vacío si hay una sola."""
    chips = []
    for f in rpc("plugin://skin.cat/?mode=seasons&bg=1&src=" + src):
        label = f.get("label", "").strip()
        m = re.match(r"T(\d+)$", label)
        if m:
            chips.append((int(m.group(1)), label))
        elif label.lower().startswith("esp"):
            chips.append((0, label))
    return chips[:MAX_SEASONS]


def current(src):
    return win.getProperty("SkinCat.Prefetch.Src") == src


def wait_loaded(key, src, monitor):
    """Espera a que el plugin diga que ha servido esa temporada (key = su número, o "d" para la de por defecto) de la serie `src`.
    False si se cierra el sheet, se abre otra serie o se agota el tiempo."""
    t0 = time.time()
    while time.time() - t0 < LOAD_TIMEOUT:
        if monitor.abortRequested() or not current(src):
            return False
        if not xbmc.getCondVisibility("Window.IsActive(1114)"):
            return False
        if win.getProperty("SkinCat.Sheet.Done.%s" % key) == src:
            return True
        monitor.waitForAbort(0.3)
    return False


def focus_list():
    """Kodi no enfoca una lista vacía: al abrir el sheet el foco inicial se pierde y hay que devolvérselo a la lista de la temporada
    mostrada en cuanto tiene capítulos (salvo que el usuario ya haya movido el foco a un chip o a una lista)."""
    chips_or_lists = "|".join("Control.HasFocus(%d)" % i for i in list(range(101, 101 + MAX_SEASONS)) + list(range(191, 191 + MAX_SEASONS)))
    if not xbmc.getCondVisibility(chips_or_lists):
        xbmc.executebuiltin("SetFocus(%d)" % (100 + int(win.getProperty("SkinCat.Sheet.Season") or 1)))


def process(src, monitor):
    win.setProperty("SkinCat.Prefetch.Status", "Preparando las temporadas…")
    chips = season_chips(src)
    if not current(src):
        return
    n = len(chips)
    win.setProperty("SkinCat.Sheet.Count", str(max(n, 1)))
    for k in range(1, MAX_SEASONS + 1):
        if k <= n:
            win.setProperty("SkinCat.Sheet.Chip.%d" % k, chips[k - 1][1])
        else:
            win.clearProperty("SkinCat.Sheet.Chip.%d" % k)
        if k >= 2:  # nada heredado de la serie anterior
            win.clearProperty("SkinCat.Sheet.Url.%d" % k)
    ok1 = wait_loaded("d", src, monitor)   # la temporada por defecto la carga el XML; se espera a que termine
    if ok1:
        focus_list()
    if n <= 1:
        log("una sola temporada (o sin temporadas): nada que adelantar")
        win.clearProperty("SkinCat.Prefetch.Status")
        return
    log("serie con %d temporadas: %s" % (n, [c[0] for c in chips]))
    if not ok1:
        return
    for k in range(2, n + 1):
        if monitor.abortRequested() or not current(src):
            log("cambio de serie: se abandona ésta")
            return
        win.setProperty("SkinCat.Prefetch.Status", "Cargando el resto de temporadas… %d de %d" % (k - 1, n - 1))
        t0 = time.time()
        win.setProperty("SkinCat.Sheet.Url.%d" % k, "plugin://skin.cat/?mode=sheet&bg=1&season=%d&src=%s" % (chips[k - 1][0], src))
        if not wait_loaded(str(chips[k - 1][0]), src, monitor):
            log("temporada %d sin cargar (sheet cerrado, otra serie o tiempo agotado)" % k)
            win.clearProperty("SkinCat.Prefetch.Status")
            return
        log("temporada %d lista en %.1f s" % (k, time.time() - t0))
    win.clearProperty("SkinCat.Prefetch.Status")
    log("temporadas cargadas")


def main():
    src = xbmc.getInfoLabel("Skin.String(sheet_src)")
    if not src:
        return
    win.setProperty("SkinCat.Sheet.Ok", "1" if win.getProperty("SkinCat.Sheet.Ready") == src else "")
    win.setProperty("SkinCat.Prefetch.Src", src)
    if win.getProperty("SkinCat.Prefetch.Running") == "1":
        return  # el trabajador en marcha verá la serie nueva en cuanto termine lo que esté haciendo
    win.setProperty("SkinCat.Prefetch.Running", "1")
    monitor = xbmc.Monitor()
    cur = src
    try:
        while not monitor.abortRequested():
            cur = win.getProperty("SkinCat.Prefetch.Src")
            try:
                process(cur, monitor)
            except Exception as e:
                log("error: %r" % e)
            if win.getProperty("SkinCat.Prefetch.Src") == cur:
                break
    finally:
        win.clearProperty("SkinCat.Prefetch.Running")
        win.clearProperty("SkinCat.Prefetch.Status")
        if win.getProperty("SkinCat.Prefetch.Src") and win.getProperty("SkinCat.Prefetch.Src") != cur:  # carrera: llegó otra serie al salir
            xbmc.executebuiltin("RunScript(special://skin/scripts/skincat_prefetch.py)")


main()
