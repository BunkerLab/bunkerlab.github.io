# -*- coding: utf-8 -*-
"""SkinCat: prueba de rendimiento guiada (Menú > "Prueba de rendimiento").

Recorre el Home como lo haría una persona con el mando (desplazarse por una fila, cambiar de fila, volver) durante ~30 s y
muestra los fotogramas por segundo que Kodi dibuja (System.FPS) en cada tramo, junto con el equipo, la resolución y la memoria.
El resultado se guarda también en addon_data/skin.cat/perf_log.txt para poder comparar dispositivos y versiones.

Qué mirar: >= 50 fps = fluido; 30-50 = aceptable; < 30 = tirones. El "peor 10 %" importa más que la media: es lo que se
nota como parón.
"""
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/skin.cat/")
win = xbmcgui.Window(10000)


def fps_now():
    try:
        return float(xbmc.getInfoLabel("System.FPS").replace(",", ".").split()[0])
    except (ValueError, IndexError):
        return None


def action(name):
    xbmc.executebuiltin("Action(%s)" % name)


def phase(name, steps, pause, samples):
    """steps = lista de acciones; se pulsan cada `pause` s mientras se muestrea System.FPS cada 0,2 s."""
    mine = []
    for a in steps:
        action(a)
        t0 = time.time()
        while time.time() - t0 < pause:
            v = fps_now()
            if v is not None:
                mine.append(v)
            xbmc.sleep(200)
    samples.append((name, mine))


def stats(vals):
    if not vals:
        return None
    s = sorted(vals)
    low = s[: max(1, len(s) // 10)]
    return {"n": len(s), "avg": sum(s) / len(s), "min": s[0], "low10": sum(low) / len(low),
            "under30": 100.0 * sum(1 for v in s if v < 30) / len(s)}


def platform():
    for cond, name in (("System.Platform.Android", "Android"), ("System.Platform.Windows", "Windows"),
                       ("System.Platform.OSX", "macOS"), ("System.Platform.Linux", "Linux")):
        if xbmc.getCondVisibility(cond):
            return name
    return "?"


def main():
    # el menú (diálogo) se está cerrando: esperar y volver al Home
    t0 = time.time()
    while xbmc.getCondVisibility("Window.IsActive(1115)") and time.time() - t0 < 5:
        xbmc.sleep(100)
    xbmc.executebuiltin("ActivateWindow(home)")
    xbmc.sleep(2500)
    configured = bool(xbmc.getInfoLabel("Skin.String(widget1path)"))
    dlg = xbmcgui.DialogProgress()
    dlg.create("Prueba de rendimiento", "No toques el mando: la prueba lo hace sola (unos 30 s)…")
    dlg.close()  # el diálogo tapa el Home y falsearía la medida: se avisa con una notificación en su lugar
    xbmcgui.Dialog().notification("SkinCat", "Prueba de rendimiento: no toques el mando (30 s)", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.sleep(4200)
    xbmc.executebuiltin("SetFocus(9001)")
    xbmc.sleep(600)
    samples = []
    action("Down")  # a la primera fila
    xbmc.sleep(1200)
    phase("Desplazar una fila (derecha)", ["Right"] * 14, 0.35, samples)
    phase("Desplazar una fila (izquierda)", ["Left"] * 14, 0.35, samples)
    phase("Cambiar de fila (abajo)", ["Down"] * 4, 1.0, samples)
    phase("Desplazar otra fila", ["Right"] * 10, 0.35, samples)
    phase("Cambiar de fila (arriba)", ["Up"] * 4, 1.0, samples)
    action("Up")
    xbmc.sleep(500)
    allv = [v for _, vs in samples for v in vs]
    lines = []
    tot = stats(allv)
    lines.append("Equipo: %s · Kodi %s · %s" % (platform(), xbmc.getInfoLabel("System.BuildVersionShort"),
                                                xbmc.getInfoLabel("System.ScreenResolution")))
    lines.append("Memoria: %s usada de %s" % (xbmc.getInfoLabel("System.Memory(used)"), xbmc.getInfoLabel("System.Memory(total)")))
    lines.append("Skin: SkinCat %s" % xbmc.getInfoLabel("System.AddonVersion(skin.cat)"))
    if not configured:
        lines.append("[COLOR ffe07070]Aviso: no hay filas configuradas; la prueba no es representativa.[/COLOR]")
    lines.append("")
    for name, vs in samples:
        st = stats(vs)
        if st:
            lines.append("%-34s media %4.0f fps · mín %3.0f · peor 10 %% %3.0f" % (name, st["avg"], st["min"], st["low10"]))
    lines.append("")
    if tot:
        verdict = "FLUIDO" if tot["low10"] >= 45 else ("ACEPTABLE" if tot["low10"] >= 28 else "CON TIRONES")
        lines.append("[B]TOTAL: media %.0f fps · peor 10 %% %.0f fps · %.0f %% del tiempo por debajo de 30 fps → %s[/B]"
                     % (tot["avg"], tot["low10"], tot["under30"], verdict))
        lines.append("(%d muestras en %d tramos)" % (tot["n"], len(samples)))
    else:
        lines.append("No se pudo leer System.FPS en este equipo.")
    text = "\n".join(lines)
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(os.path.join(DATA_DIR, "perf_log.txt"), "a", encoding="utf-8") as f:
            f.write("=== %s ===\n%s\n\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), text.replace("[B]", "").replace("[/B]", "")))
    except OSError:
        pass
    xbmc.log("[SkinCat perf] %s" % text.replace("\n", " | "), xbmc.LOGINFO)
    xbmcgui.Dialog().textviewer("Resultado de la prueba de rendimiento", text)


main()
