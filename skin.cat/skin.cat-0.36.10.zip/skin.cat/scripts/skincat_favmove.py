# -*- coding: utf-8 -*-
"""SkinCat: "Mover a otra posición…" para los favoritos de Kodi de la fila "Favoritos de Kodi".

Lo lanza el menú contextual de Kodi (pulsación larga en OK en Android/Fire TV, tecla C en el Mac): addon.xml lo registra con
kodi.context.item y solo es visible en los elementos con la propiedad skincat_fav (los pone scripts/skincat_rows.py).

Kodi no tiene "mover" para favoritos (el orden es el del fichero favourites.xml, y la fila los enseña del más reciente al más
antiguo). Con la API JSON solo se puede añadir al final o quitar: para cambiar el orden se QUITAN los favoritos desde el primero
que cambia de sitio hasta el final y se vuelven a AÑADIR en el orden nuevo. Por seguridad:
  * antes de tocar nada se copia favourites.xml a addon_data/skin.cat/favourites.backup.xml;
  * solo se reordena si todos los favoritos afectados son de tipo "media" o "window" (los scripts y apps no se tocan);
  * al final se comprueba el orden y, si falta alguno, se vuelve a añadir.
"""
import json
import re
import sys
import time

import xbmc
import xbmcgui
import xbmcvfs

TAGS = re.compile(r"\[/?(?:COLOR[^\]]*|B|I|CR)\]", re.I)
FAVS = "special://profile/favourites.xml"
BACKUP = "special://profile/addon_data/skin.cat/favourites.backup.xml"
PROPS = ["path", "window", "windowparameter", "thumbnail"]


def log(msg):
    xbmc.log("[SkinCat favmove] %s" % msg, xbmc.LOGINFO)


def rpc(method, params=None):
    res = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}})))
    if "error" in res:
        raise RuntimeError("%s: %s" % (method, res["error"]))
    return res.get("result") or {}


def get_favs():
    return rpc("Favourites.GetFavourites", {"properties": PROPS}).get("favourites") or []


def shown_path(f):
    """Misma regla que la fila (scripts/skincat_rows.py, favourites()): lo que no se enseña no se mueve."""
    if f.get("type") == "media" and f.get("path"):
        return f["path"].rstrip("/")
    if f.get("type") == "window" and f.get("windowparameter"):
        return f["windowparameter"].rstrip("/")
    return None


def key(f):
    return (f.get("type"), (f.get("path") or "").rstrip("/"), f.get("window") or "", (f.get("windowparameter") or "").rstrip("/"))


def toggle(f):
    """AddFavourite alterna: si ya existe lo quita; si no, lo añade al final."""
    params = {"title": f.get("title", ""), "type": f["type"], "thumbnail": f.get("thumbnail") or ""}
    if f["type"] == "window":
        params["window"] = f.get("window") or "videos"
        params["windowparameter"] = f.get("windowparameter") or ""
    else:
        params["path"] = f.get("path") or ""
    rpc("Favourites.AddFavourite", params)


def reorder(favs, new_displayed):
    """favs = orden del fichero; new_displayed = orden nuevo de la fila (el más reciente primero). Devuelve el orden nuevo del fichero."""
    slots = [i for i, f in enumerate(favs) if shown_path(f)]
    new_file = list(favs)
    for slot, f in zip(slots, reversed(new_displayed)):
        new_file[slot] = f
    return new_file


def apply_order(old, new):
    """Quita y vuelve a añadir desde el primer favorito que cambia de sitio. Devuelve (ok, mensaje)."""
    d = next((i for i, (a, b) in enumerate(zip(old, new)) if key(a) != key(b)), None)
    if d is None:
        return True, ""
    region = old[d:]
    if any(f.get("type") not in ("media", "window") for f in region):
        return False, "Hay favoritos de otro tipo (scripts o apps) entre medias: no se pueden mover con seguridad."
    try:
        xbmcvfs.copy(FAVS, BACKUP)
    except Exception as e:
        log("no se pudo copiar la copia de seguridad: %r" % e)
        return False, "No se pudo guardar la copia de seguridad de los favoritos."
    log("reordenando desde el puesto %d de %d (%d favoritos)" % (d, len(old), len(region)))
    for f in region:
        toggle(f)
    left = get_favs()
    if len(left) != d:
        log("tras quitar quedan %d (esperados %d)" % (len(left), d))
    present = {key(f) for f in left}
    for f in new[d:]:
        if key(f) not in present:
            toggle(f)
            present.add(key(f))
    final = get_favs()
    if [key(f) for f in final] == [key(f) for f in new]:
        return True, ""
    missing = [f for f in new if key(f) not in {key(x) for x in final}]
    for f in missing:  # último recurso: que no se pierda ninguno
        toggle(f)
    log("orden final distinto del esperado; faltaban %d" % len(missing))
    return False, "El orden no quedó exactamente como se pidió (no se ha perdido ningún favorito; copia en %s)." % BACKUP


def main():
    li = getattr(sys, "listitem", None)
    here = (li.getPath() if li else xbmc.getInfoLabel("ListItem.FolderPath") or xbmc.getInfoLabel("ListItem.FileNameAndPath")).rstrip("/")
    cid = xbmc.getInfoLabel("System.CurrentControlID")
    favs = get_favs()
    displayed = [f for f in reversed(favs) if shown_path(f)]
    idx = next((i for i, f in enumerate(displayed) if shown_path(f) == here), None)
    if idx is None or len(displayed) < 2:
        xbmcgui.Dialog().notification("SkinCat", "No hay otro favorito con el que reordenar", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    names = [TAGS.sub("", f.get("title", "")).strip() or "Favorito %d" % (i + 1) for i, f in enumerate(displayed)]
    labels = ["%d  ·  %s%s" % (i + 1, n, "      (aquí está ahora)" if i == idx else "") for i, n in enumerate(names)]
    choice = xbmcgui.Dialog().select("Mover «%s» a la posición…" % names[idx], labels, preselect=idx)
    if choice < 0 or choice == idx:
        return
    new_displayed = list(displayed)
    new_displayed.insert(choice, new_displayed.pop(idx))
    ok, msg = apply_order(favs, reorder(favs, new_displayed))
    if not ok:
        xbmcgui.Dialog().ok("SkinCat", msg)
    else:
        xbmcgui.Dialog().notification("SkinCat", "Favorito movido a la posición %d" % (choice + 1), xbmcgui.NOTIFICATION_INFO, 3000)
    # refrescar la fila y devolverle el foco al elemento movido (el servicio recarga las filas al cerrarse el diálogo)
    xbmcgui_win = xbmcgui.Window(10000)
    xbmcgui_win.setProperty("SkinCat.Reload", "%d" % int(time.time() * 1000))
    if cid.startswith("902"):
        xbmc.sleep(1500)
        xbmc.executebuiltin("SetFocus(%s,%d,absolute)" % (cid, choice))


main()
