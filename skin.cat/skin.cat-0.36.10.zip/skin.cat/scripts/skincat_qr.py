# -*- coding: utf-8 -*-
"""SkinCat: generador de códigos QR mínimo (solo biblioteca estándar de Python).

Escrito a propósito sin dependencias: Kodi no trae ninguna librería de QR y no se quiere meter código ajeno en la skin.
Soporta lo que hace falta para una dirección web corta de la red local: modo byte, corrección de errores M, versiones 1-6
(hasta 106 bytes; las versiones 7+ necesitan bloques de "información de versión" que no se implementan).

    make("http://192.168.1.50:8765/?t=abc")  -> matriz de booleanos (True = módulo oscuro)
    save_png(ruta, matriz, scale=12, border=4)

Verificado descodificando las imágenes con el detector de QR de macOS (ver devtools/skincat.py, escenario "phone").
"""
import struct
import zlib

# versión -> (palabras de datos, nº de bloques, palabras de corrección por bloque), nivel M
_M = {1: (16, 1, 10), 2: (28, 1, 16), 3: (44, 1, 26), 4: (64, 2, 18), 5: (86, 2, 24), 6: (108, 4, 16)}
_ALIGN = {1: [], 2: [18], 3: [22], 4: [26], 5: [30], 6: [34]}  # centro (c, c) del único patrón de alineación


# ------------------------------------------------------------------ Reed-Solomon sobre GF(256), polinomio 0x11D
_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _mul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


def _generator(n):
    g = [1]
    for i in range(n):
        nxt = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            nxt[j] ^= c
            nxt[j + 1] ^= _mul(c, _EXP[i])
        g = nxt
    return g


def _rs_remainder(data, n):
    gen = _generator(n)
    rem = [0] * n
    for b in data:
        factor = b ^ rem[0]
        rem = rem[1:] + [0]
        if factor:
            for i in range(n):
                rem[i] ^= _mul(gen[i + 1], factor)
    return rem


# ------------------------------------------------------------------ datos
def _codewords(payload, version):
    ndata, nblocks, necc = _M[version]
    bits = "0100" + format(len(payload), "08b") + "".join(format(b, "08b") for b in payload)
    bits += "0" * min(4, ndata * 8 - len(bits))
    bits += "0" * (-len(bits) % 8)
    data = [int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)]
    pad = (0xEC, 0x11)
    while len(data) < ndata:
        data.append(pad[(len(data) - len(bits) // 8) % 2])
    size = ndata // nblocks
    blocks = [data[i * size:(i + 1) * size] for i in range(nblocks)]
    eccs = [_rs_remainder(b, necc) for b in blocks]
    out = []
    for i in range(size):
        out += [b[i] for b in blocks]
    for i in range(necc):
        out += [e[i] for e in eccs]
    return out


# ------------------------------------------------------------------ matriz
class _Matrix:
    def __init__(self, version):
        self.v = version
        self.n = 17 + 4 * version
        self.m = [[False] * self.n for _ in range(self.n)]
        self.fn = [[False] * self.n for _ in range(self.n)]
        self._patterns()

    def _set(self, x, y, dark):
        self.m[y][x] = dark
        self.fn[y][x] = True

    def _finder(self, cx, cy):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < self.n and 0 <= y < self.n:
                    dist = max(abs(dx), abs(dy))
                    self._set(x, y, dist not in (2, 4))

    def _patterns(self):
        n = self.n
        for i in range(n):  # sincronización
            self._set(6, i, i % 2 == 0)
            self._set(i, 6, i % 2 == 0)
        self._finder(3, 3)
        self._finder(n - 4, 3)
        self._finder(3, n - 4)
        for c in _ALIGN[self.v]:
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    self._set(c + dx, c + dy, max(abs(dx), abs(dy)) != 1)
        self._format(0)  # reserva las zonas de formato

    def _format(self, mask):
        data = (0 << 3) | mask  # nivel M = 00
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = ((data << 10) | rem) ^ 0x5412
        bit = lambda i: ((bits >> i) & 1) == 1
        n = self.n
        for i in range(0, 6):
            self._set(8, i, bit(i))
        self._set(8, 7, bit(6))
        self._set(8, 8, bit(7))
        self._set(7, 8, bit(8))
        for i in range(9, 15):
            self._set(14 - i, 8, bit(i))
        for i in range(0, 8):
            self._set(n - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self._set(8, n - 15 + i, bit(i))
        self._set(8, n - 8, True)  # módulo oscuro fijo

    def place(self, codewords):
        n, i = self.n, 0
        total = len(codewords) * 8
        right = n - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(n):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = n - 1 - vert if upward else vert
                    if not self.fn[y][x] and i < total:
                        self.m[y][x] = ((codewords[i >> 3] >> (7 - (i & 7))) & 1) == 1
                        i += 1
            right -= 2

    def mask(self, k):
        for y in range(self.n):
            for x in range(self.n):
                if self.fn[y][x]:
                    continue
                inv = (
                    (x + y) % 2 == 0, y % 2 == 0, x % 3 == 0, (x + y) % 3 == 0,
                    (x // 3 + y // 2) % 2 == 0, x * y % 2 + x * y % 3 == 0,
                    (x * y % 2 + x * y % 3) % 2 == 0, ((x + y) % 2 + x * y % 3) % 2 == 0,
                )[k]
                if inv:
                    self.m[y][x] = not self.m[y][x]

    def penalty(self):
        n, m, score = self.n, self.m, 0
        lines = ["".join("1" if c else "0" for c in row) for row in m]
        lines += ["".join("1" if m[y][x] else "0" for y in range(n)) for x in range(n)]
        for s in lines:
            run = 1
            for i in range(1, n):
                if s[i] == s[i - 1]:
                    run += 1
                else:
                    score += 3 + (run - 5) if run >= 5 else 0
                    run = 1
            score += 3 + (run - 5) if run >= 5 else 0
            padded = "0000" + s + "0000"
            for pat in ("00001011101", "10111010000"):
                start = 0
                while True:
                    at = padded.find(pat, start)
                    if at < 0:
                        break
                    score += 40
                    start = at + 1
        for y in range(n - 1):
            for x in range(n - 1):
                if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    score += 3
        dark = sum(c for row in m for c in row)
        total = n * n
        score += ((abs(dark * 20 - total * 10) + total - 1) // total - 1) * 10
        return score


def make(text):
    payload = text.encode("utf-8")
    version = next((v for v in sorted(_M) if len(payload) <= _M[v][0] - 2), None)
    if version is None:
        raise ValueError("texto demasiado largo para este generador de QR (%d bytes)" % len(payload))
    words = _codewords(payload, version)
    best = None
    for k in range(8):
        mt = _Matrix(version)
        mt.place(words)
        mt.mask(k)
        mt._format(k)
        p = mt.penalty()
        if best is None or p < best[0]:
            best = (p, mt)
    return best[1].m


def save_png(path, matrix, scale=12, border=4):
    n = len(matrix)
    side = (n + 2 * border) * scale
    rows = []
    blank = b"\xff" * side
    for y in range(-border, n + border):
        if 0 <= y < n:
            line = bytearray()
            for x in range(-border, n + border):
                dark = 0 <= x < n and matrix[y][x]
                line += (b"\x00" if dark else b"\xff") * scale
            line = bytes(line)
        else:
            line = blank
        rows += [b"\x00" + line] * scale

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", side, side, 8, 0, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(b"".join(rows), 6)) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)
