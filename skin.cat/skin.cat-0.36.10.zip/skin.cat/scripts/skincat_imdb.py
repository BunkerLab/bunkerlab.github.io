# -*- coding: utf-8 -*-
"""SkinCat: servicio en segundo plano del Home (notas de IMDb + título limpio).

Se lanza desde Home.xml (<onload>RunScript(special://skin/scripts/skincat_imdb.py)</onload>) y se queda
mientras Kodi esté abierto (una sola instancia).

NOTAS DE IMDb (sin claves ni límites)
  Palantir identifica cada título con su id de TMDB (ListItem.UniqueID(tmdb)), no con el de IMDb:
  1. PRECARGA: cuando una fila del Home carga (o crece con "Cargar más"), se leen TODOS sus títulos y los
     ids de TMDB que no estén en la caché se traducen a ids de IMDb de una vez y se guardan para siempre
     en mapping.db (los "no encontrado" se reintentan a los 3 días). Así, en el 2º arranque ya está todo.
       - Con clave gratuita de TMDB (fichero addon_data/<skin>/tmdb_key.txt): API de TMDB (~100 %).
       - Sin clave: Wikidata (P4947/P4983 -> P345), consultas por lotes (~75 % de los estrenos).
  2. IMDb id -> nota y votos: dataset público https://datasets.imdbws.com/title.ratings.tsv.gz
     (~9 MB, uso personal no comercial) convertido a SQLite y refrescado cada 7 días.

TÍTULO LIMPIO
  Palantir mete año, idiomas y calidad dentro del título con etiquetas de color. Se separan en propiedades.

PROPIEDADES (Window(Home)), con <k> = Focus (elemento enfocado) o Row1 (primero de la fila 1 / enfocado):
  SkinCat.<k>.Title / .Year / .Langs / .Quality      SkinCat.IMDb.<k>.Rating / .Votes
Solo usa la biblioteca estándar de Python que incluye Kodi.
"""
import gzip
import json
import os
import re
import shutil
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcvfs

import skincat_watch as watch

SKIN_ID = "skin.cat"
URL = "https://datasets.imdbws.com/title.ratings.tsv.gz"
REFRESH_SECONDS = 7 * 24 * 3600
NEG_TTL = 3 * 24 * 3600
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s/" % SKIN_ID)
DB_PATH = os.path.join(DATA_DIR, "imdb_ratings.db")
MAP_PATH = os.path.join(DATA_DIR, "mapping.db")
KEY_PATH = os.path.join(DATA_DIR, "tmdb_key.txt")
LOGO_PATH = os.path.join(DATA_DIR, "logos.db")
LOGO_BASE = "https://image.tmdb.org/t/p/w780"  # más nítido en pantalla grande
LOGO_TTL = 30 * 24 * 3600      # un logo encontrado se vuelve a mirar cada mes
LOGO_NEG_TTL = 3 * 24 * 3600   # "sin logo" se reintenta a los 3 días
UA = {"User-Agent": "SkinCat-Kodi/1.0 (personal use)"}
SOURCES = {"Focus": "ListItem", "Row1": "Container(9021).ListItem"}
HOME_ROWS = 24  # igual que devtools/gen_rows.py (ids de panel: 902 + nº de fila: 9020 = "Continuar viendo", 9021..9029, 90210..90224)
ROW_CONTAINERS = tuple(int("902%d" % n) for n in range(0, HOME_ROWS + 1)) + tuple(range(9211, 9219))  # Home + ventana de búsqueda
ACTIVE = "[Window.IsActive(home) | Window.IsActive(1111) | Window.IsActive(movieinformation) | Window.IsActive(1113)] + !Window.IsVisible(1114) + !Window.IsVisible(contextmenu) + !Window.IsVisible(selectdialog)"
PLOT_LONG = 230  # nº de caracteres a partir del cual la sinopsis no cabe en la cabecera
RUNNING = "SkinCat.Ratings.Running"
BATCH = 40
CACHE_DIR = os.path.join(DATA_DIR, "pagecache")
# diálogos de Kodi desde los que Palantir puede cambiar datos (menú contextual: añadir a favoritos; selección de fuente...)
MODAL = "Window.IsVisible(contextmenu) | Window.IsVisible(selectdialog) | Window.IsVisible(yesnodialog) | Window.IsVisible(okdialog)"

win = xbmcgui.Window(10000)
_lock = threading.Lock()
_inflight = set()
_mem_map = {}      # (kind, tmdb) -> imdb id | None
_mem_rating = {}   # imdb id -> (rating, votes)
_mem_logo = {}     # (kind, tmdb) -> url del logo | ""
_logo_inflight = set()
_version = 0       # sube cada vez que llegan datos nuevos, para re-evaluar el elemento enfocado
_build_state = [""]  # texto para el diagnóstico (vacío = la base de notas no se está construyendo)


def log(msg):
    xbmc.log("[SkinCat IMDb] %s" % msg, xbmc.LOGINFO)


# ------------------------------------------------------------------ dataset de IMDb
def build_db():
    global _version
    os.makedirs(DATA_DIR, exist_ok=True)
    gz_path = os.path.join(DATA_DIR, "title.ratings.tsv.gz")
    new_db = DB_PATH + ".new"
    t_build = time.time()
    try:
        _build_state[0] = "IMDb: descargando"
        log("descargando %s" % URL)
        req = urllib.request.Request(URL, headers=UA)
        with urllib.request.urlopen(req, timeout=60) as r, open(gz_path, "wb") as f:
            shutil.copyfileobj(r, f)
        if os.path.exists(new_db):
            os.remove(new_db)
        con = sqlite3.connect(new_db)
        con.execute("CREATE TABLE r (id INTEGER PRIMARY KEY, rating REAL, votes INTEGER)")
        batch = []
        rows = 0
        _build_state[0] = "IMDb: construyendo la base"
        with gzip.open(gz_path, "rt", encoding="utf-8") as f:
            next(f)
            for line in f:
                rows += 1
                t, rating, votes = line.rstrip("\n").split("\t")
                batch.append((int(t[2:]), float(rating), int(votes)))
                if len(batch) >= 50000:
                    con.executemany("INSERT INTO r VALUES (?,?,?)", batch)
                    batch = []
                    _build_state[0] = "IMDb: construyendo la base (%d mil filas)" % (rows // 1000)
        if batch:
            con.executemany("INSERT INTO r VALUES (?,?,?)", batch)
        con.commit()
        n = con.execute("SELECT COUNT(*) FROM r").fetchone()[0]
        con.close()
        os.replace(new_db, DB_PATH)
        _mem_rating.clear()
        _version += 1
        log("base de notas lista: %d títulos en %.0f s" % (n, time.time() - t_build))
    except Exception as e:
        log("error construyendo la base de notas: %r" % e)
    finally:
        _build_state[0] = ""
        for p in (gz_path, new_db):
            try:
                if os.path.exists(p):
                    os.remove(p)
            except OSError:
                pass


def db_is_stale():
    return not os.path.exists(DB_PATH) or time.time() - os.path.getmtime(DB_PATH) > REFRESH_SECONDS


def rating_for(imdb_id):
    if not imdb_id:
        return None
    if imdb_id in _mem_rating:
        return _mem_rating[imdb_id]
    if not os.path.exists(DB_PATH):
        return None
    try:
        con = sqlite3.connect(DB_PATH)
        row = con.execute("SELECT rating, votes FROM r WHERE id=?", (imdb_id,)).fetchone()
        con.close()
    except sqlite3.Error:
        return None
    _mem_rating[imdb_id] = row
    return row


def fmt_votes(v):
    if v >= 1000000:
        return "%.1fM" % (v / 1000000.0)
    if v >= 1000:
        return "%dK" % round(v / 1000.0)
    return str(v)


# ------------------------------------------------------------------ TMDB id -> IMDb id (caché)
def _map_con():
    con = sqlite3.connect(MAP_PATH, timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS m (kind TEXT, tmdb INTEGER, imdb INTEGER, ts REAL, PRIMARY KEY(kind,tmdb))")
    return con


def map_get(kind, tmdb):
    """(en_caché, imdb|None)"""
    k = (kind, tmdb)
    if k in _mem_map:
        return True, _mem_map[k]
    try:
        con = _map_con()
        row = con.execute("SELECT imdb, ts FROM m WHERE kind=? AND tmdb=?", (kind, tmdb)).fetchone()
        con.close()
    except sqlite3.Error:
        return False, None
    if row is None or (row[0] is None and time.time() - row[1] > NEG_TTL):
        return False, None
    _mem_map[k] = row[0]
    return True, row[0]


def map_put_many(items):
    """items: [(kind, tmdb, imdb|None)]"""
    try:
        with _lock:
            con = _map_con()
            con.executemany("INSERT OR REPLACE INTO m VALUES (?,?,?,?)", [(k, t, i, time.time()) for k, t, i in items])
            con.commit()
            con.close()
    except sqlite3.Error as e:
        log("error guardando mapa: %r" % e)
    for k, t, i in items:
        _mem_map[(k, t)] = i


def tmdb_key():
    try:
        with open(KEY_PATH, "r") as f:
            return f.read().strip()
    except OSError:
        return ""


def http_json(url, headers=None):
    req = urllib.request.Request(url, headers=dict(UA, **(headers or {})))
    with urllib.request.urlopen(req, timeout=25) as r:
        return json.loads(r.read().decode("utf-8"))


def resolve_with_tmdb(kind, tmdb, key):
    url = "https://api.themoviedb.org/3/%s/%d/external_ids" % ("tv" if kind == "tv" else "movie", tmdb)
    headers = {}
    if key.startswith("eyJ"):
        headers["Authorization"] = "Bearer " + key
    else:
        url += "?api_key=" + key
    try:
        m = re.search(r"(\d+)", http_json(url, headers).get("imdb_id") or "")
        return int(m.group(1)) if m else None
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def resolve_with_wikidata(kind, ids):
    """Un único SPARQL para varios ids. Devuelve {tmdb: imdb}."""
    prop = "P4983" if kind == "tv" else "P4947"
    q = 'SELECT ?t ?i WHERE { VALUES ?t { %s } ?x wdt:%s ?t . ?x wdt:P345 ?i }' % (
        " ".join('"%d"' % i for i in ids), prop)
    url = "https://query.wikidata.org/sparql?format=json&query=" + urllib.parse.quote(q)
    out = {}
    for b in http_json(url)["results"]["bindings"]:
        m = re.search(r"tt(\d+)", b["i"]["value"])
        if m and b["t"]["value"].isdigit():
            out[int(b["t"]["value"])] = int(m.group(1))
    return out


def prefetch(pairs):
    """Resuelve en segundo plano todos los (kind, tmdb) que aún no estén en caché."""
    global _version
    todo = []
    with _lock:
        for kind, tmdb in pairs:
            if (kind, tmdb) in _inflight or map_get(kind, tmdb)[0]:
                continue
            _inflight.add((kind, tmdb))
            todo.append((kind, tmdb))
    if not todo:
        return

    def work():
        global _version
        try:
            key = tmdb_key()
            for kind in ("movie", "tv"):
                ids = [t for k, t in todo if k == kind]
                if not ids:
                    continue
                if key:
                    res = []
                    for t in ids:
                        try:
                            res.append((kind, t, resolve_with_tmdb(kind, t, key)))
                        except Exception as e:
                            log("TMDB %s/%s: %r" % (kind, t, e))
                        time.sleep(0.03)
                    map_put_many(res)
                else:
                    for i in range(0, len(ids), BATCH):
                        chunk = ids[i:i + BATCH]
                        try:
                            found = resolve_with_wikidata(kind, chunk)
                            map_put_many([(kind, t, found.get(t)) for t in chunk])
                        except Exception as e:
                            log("Wikidata %s (%d ids): %r" % (kind, len(chunk), e))
                        _version += 1
            log("precarga terminada: %d títulos nuevos" % len(todo))
        finally:
            with _lock:
                for p in todo:
                    _inflight.discard(p)
            _version += 1

    threading.Thread(target=work, daemon=True).start()


def kind_of(dbtype):
    return "tv" if dbtype in ("tvshow", "season", "episode") else "movie"


def imdb_for(prefix):
    imdb = xbmc.getInfoLabel(prefix + ".UniqueID(imdb)")
    m = re.search(r"tt(\d+)", imdb or "")
    if m:
        return int(m.group(1))
    tmdb = xbmc.getInfoLabel(prefix + ".UniqueID(tmdb)")
    if not tmdb.isdigit():
        return None
    kind = kind_of(xbmc.getInfoLabel(prefix + ".DBType"))
    found, val = map_get(kind, int(tmdb))
    if found:
        return val
    prefetch([(kind, int(tmdb))])
    return None


# ------------------------------------------------------------------ logos de los títulos (TMDB /images)
def _logo_con():
    con = sqlite3.connect(LOGO_PATH, timeout=10)
    con.execute("CREATE TABLE IF NOT EXISTS l (kind TEXT, tmdb INTEGER, url TEXT, ts REAL, PRIMARY KEY(kind,tmdb))")
    return con


def logo_get(kind, tmdb):
    """(conocido, url). url "" = TMDB no tiene logo. Caduca: mes si hay logo, 3 días si no."""
    k = (kind, tmdb)
    if k in _mem_logo:
        return True, _mem_logo[k]
    try:
        con = _logo_con()
        row = con.execute("SELECT url, ts FROM l WHERE kind=? AND tmdb=?", (kind, tmdb)).fetchone()
        con.close()
    except sqlite3.Error:
        return False, ""
    if row and time.time() - row[1] < (LOGO_TTL if row[0] else LOGO_NEG_TTL):
        _mem_logo[k] = row[0]
        return True, row[0]
    return False, ""


def logo_put(kind, tmdb, url):
    _mem_logo[(kind, tmdb)] = url
    try:
        con = _logo_con()
        con.execute("INSERT OR REPLACE INTO l VALUES (?,?,?,?)", (kind, tmdb, url, time.time()))
        con.commit()
        con.close()
    except sqlite3.Error as e:
        log("error guardando logo: %r" % e)


def pick_logo(images):
    """Mejor logo PNG: primero en español, luego inglés, luego sin idioma; dentro de cada idioma el más votado."""
    order = {"es": 0, "en": 1, None: 2}
    best = None
    for im in images.get("logos") or []:
        path = im.get("file_path") or ""
        if not path.lower().endswith(".png"):  # Kodi no pinta SVG
            continue
        rank = (order.get(im.get("iso_639_1"), 3), -(im.get("vote_average") or 0), -(im.get("width") or 0))
        if best is None or rank < best[0]:
            best = (rank, path)
    return LOGO_BASE + best[1] if best else ""


def fetch_logo(kind, tmdb, key):
    url = "https://api.themoviedb.org/3/%s/%d/images?include_image_language=es,en,null" % ("tv" if kind == "tv" else "movie", tmdb)
    headers = {}
    if key.startswith("eyJ"):
        headers["Authorization"] = "Bearer " + key
    else:
        url += "&api_key=" + key
    try:
        return pick_logo(http_json(url, headers))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return ""
        raise


def logo_prefetch(pairs, urgent=False):
    """Busca en segundo plano los logos que falten. urgent = el elemento enfocado: sale ya, sin esperar al resto de la fila."""
    global _version
    key = tmdb_key()
    if not key:
        return
    todo = []
    with _lock:
        for kind, tmdb in pairs:
            if (kind, tmdb) in _logo_inflight or logo_get(kind, tmdb)[0]:
                continue
            _logo_inflight.add((kind, tmdb))
            todo.append((kind, tmdb))
    if not todo:
        return

    def work():
        global _version
        try:
            for kind, tmdb in todo:
                if not urgent and logo_get(kind, tmdb)[0]:
                    continue
                try:
                    logo_put(kind, tmdb, fetch_logo(kind, tmdb, key))
                except Exception as e:
                    log("logo %s/%s: %r" % (kind, tmdb, e))
                finally:
                    with _lock:
                        _logo_inflight.discard((kind, tmdb))
                _version += 1
                time.sleep(0.04)
        finally:
            with _lock:
                for p_ in todo:
                    _logo_inflight.discard(p_)

    threading.Thread(target=work, daemon=True).start()


def logo_for(prefix):
    """URL del logo del elemento (o "" si no hay / aún no se sabe: entonces se pide con prioridad)."""
    tmdb = xbmc.getInfoLabel(prefix + ".UniqueID(tmdb)")
    if not tmdb.isdigit():
        return ""
    kind = kind_of(xbmc.getInfoLabel(prefix + ".DBType"))
    found, url = logo_get(kind, int(tmdb))
    if not found:
        logo_prefetch([(kind, int(tmdb))], urgent=True)
    return url


def scan_rows(sigs):
    """Detecta filas nuevas o ampliadas y precarga las notas de todos sus títulos."""
    for cid in ROW_CONTAINERS:
        n_txt = xbmc.getInfoLabel("Container(%d).NumItems" % cid)
        if not n_txt.isdigit() or int(n_txt) == 0:
            sigs.pop(cid, None)
            continue
        n = int(n_txt)
        first = xbmc.getInfoLabel("Container(%d).ListItemAbsolute(0).UniqueID(tmdb)" % cid)
        sig = (n, first)
        if sigs.get(cid) == sig:
            continue
        sigs[cid] = sig
        pairs = []
        for i in range(n):
            pre = "Container(%d).ListItemAbsolute(%d)" % (cid, i)
            t = xbmc.getInfoLabel(pre + ".UniqueID(tmdb)")
            if t.isdigit():
                pairs.append((kind_of(xbmc.getInfoLabel(pre + ".DBType")), int(t)))
        log("fila %d: %d títulos detectados" % (int(str(cid)[3:]), len(pairs)))
        prefetch(pairs)
        logo_prefetch(pairs)


# ------------------------------------------------------------------ título limpio
_TAGS = re.compile(r"\[/?(?:COLOR[^\]]*|B|I|CR)\]", re.I)
_QUALITY = re.compile(r"1080|720|480|2160|4K|\bHD|\bSD|HDR|\bDV\b|CAM|WEB|BluRay", re.I)
_PARSE = re.compile(r"^\s*(.*?)\s*(?:\((\d{4})\))?\s*((?:\[[^\]]*\]\s*)*)$")


def parse_label(label):
    clean = _TAGS.sub("", label or "").strip()
    m = _PARSE.match(clean)
    if not m:
        return clean, "", "", ""
    title, year, groups = m.group(1), m.group(2) or "", m.group(3)
    langs, quality = [], []
    for g in re.findall(r"\[([^\]]*)\]", groups):
        (quality if _QUALITY.search(g) else langs).append(g.strip())
    return title or clean, year, ", ".join(langs), ", ".join(quality)


def bump_reload(reason):
    """Vacía la caché de páginas y cambia SkinCat.Reload: las filas lo llevan en su ruta (&r=...) y se vuelven a cargar.
    Devuelve (contenedor, posición) de la fila enfocada para devolverle el foco cuando termine la carga."""
    focus = None
    for cid in ROW_CONTAINERS[:HOME_ROWS + 1]:
        if xbmc.getCondVisibility("Control.HasFocus(%d)" % cid):
            cur = xbmc.getInfoLabel("Container(%d).CurrentItem" % cid)
            focus = (cid, max(0, int(cur) - 1)) if cur.isdigit() else None
    try:
        for name in os.listdir(CACHE_DIR):
            if name.endswith(".json"):
                os.remove(os.path.join(CACHE_DIR, name))
    except OSError:
        pass
    win.setProperty("SkinCat.Reload", "%d" % int(time.time() * 1000))
    log("filas recargadas (%s)" % reason)
    return focus


def focused_row():
    """Fila del Home con el foco (0 = cabecera u otra ventana). Ids: panel 902n, engranaje 910n, botón 912n."""
    cid = xbmc.getInfoLabel("System.CurrentControlID")
    for prefix in ("902", "910", "911", "912"):
        if cid.startswith(prefix) and cid[3:].isdigit() and 1 <= int(cid[3:]) <= HOME_ROWS:
            return int(cid[3:])
    return 0


_published = {}
_loaded_upto = [2]  # filas 1..N cargadas (solo crece: lo ya cargado no se descarga al subir)


_row_r = {}  # valor de recarga (SkinCat.Reload) con el que cada fila pidió sus datos por última vez


def publish_row_sources():
    """Carga perezosa: cada fila recibe su dirección (plugin://skin.cat/?pages=..&r=..&src=..) solo cuando el foco está a
    <=2 filas de ella. El resto publica una cadena vacía y Kodi no pide nada a Palantir hasta que el foco se acerca.
    Las recargas automáticas (SkinCat.Reload) solo alcanzan a las filas cercanas al foco; las lejanas conservan su valor
    anterior y se refrescan cuando el foco se acerca, para no pedir 20 filas a Palantir cada vez que se vuelve al Home."""
    f = focused_row()
    _loaded_upto[0] = max(_loaded_upto[0], min(HOME_ROWS, f + 2))
    reload_id = win.getProperty("SkinCat.Reload")
    for n in range(0, HOME_ROWS + 1):
        url = ""
        if n <= _loaded_upto[0]:
            path = xbmc.getInfoLabel("Skin.String(widget%dpath)" % n)
            if path:
                if (f == 0 and n <= 2) or f - 1 <= n <= f + 2 or n not in _row_r:
                    _row_r[n] = reload_id
                pages = xbmc.getInfoLabel("Skin.String(widget%dpages)" % n)
                sort = xbmc.getInfoLabel("Skin.String(widget%dsort)" % n)
                url = "plugin://%s/?pages=%s&r=%s&sort=%s&src=%s" % (SKIN_ID, pages, _row_r[n], sort, path)
        if _published.get(n) != url:
            _published[n] = url
            if url:
                win.setProperty("SkinCat.Src.%d" % n, url)
            else:
                win.clearProperty("SkinCat.Src.%d" % n)


def sync_continue():
    """La fila 0 ("Continuar viendo") solo existe cuando hay algo que continuar: se activa/desactiva con widget0path."""
    has = watch.count() > 0
    cur = xbmc.getInfoLabel("Skin.String(widget0path)")
    if has and cur != watch.CONT_PATH:
        xbmc.executebuiltin('Skin.SetString(widget0title,Continuar viendo)')
        xbmc.executebuiltin('Skin.SetString(widget0path,%s)' % watch.CONT_PATH)
    elif not has and cur:
        xbmc.executebuiltin("Skin.Reset(widget0path)")


def publish_extra(prefix):
    """Datos largos del elemento enfocado para el modal de sinopsis (Window.Property no tiene problemas de comas/comillas)."""
    plot = xbmc.getInfoLabel(prefix + ".Plot")
    for name, val in (("Plot", plot),
                      ("Poster", xbmc.getInfoLabel(prefix + ".Art(poster)")),
                      ("Fanart", xbmc.getInfoLabel(prefix + ".Art(fanart)"))):
        if val:
            win.setProperty("SkinCat.Focus." + name, val)
        else:
            win.clearProperty("SkinCat.Focus." + name)
    if len(plot) > PLOT_LONG:
        win.setProperty("SkinCat.Focus.PlotLong", "1")
    else:
        win.clearProperty("SkinCat.Focus.PlotLong")


def publish(key, label, rating, logo=""):
    title, year, langs, quality = parse_label(label)
    for name, val in (("Title", title), ("Year", year), ("Langs", langs), ("Quality", quality)):
        if val:
            win.setProperty("SkinCat.%s.%s" % (key, name), val)
        else:
            win.clearProperty("SkinCat.%s.%s" % (key, name))
    if logo:
        win.setProperty("SkinCat.%s.Logo" % key, logo)
    else:
        win.clearProperty("SkinCat.%s.Logo" % key)
    base = "SkinCat.IMDb.%s." % key
    if rating:
        win.setProperty(base + "Rating", "%.1f" % rating[0])
        win.setProperty(base + "Votes", fmt_votes(rating[1]))
    else:
        win.clearProperty(base + "Rating")
        win.clearProperty(base + "Votes")


PERF_PROPS = ("FpsMin", "FpsAvg", "ServiceMs", "ServiceMax", "Build")


def sample_perf(perf, busy_ms):
    """Diagnóstico (ajuste "show_perf"): fps mínimos/medios de los últimos 10 s y lo que cuesta cada ciclo de este servicio.
    Solo trabaja mientras el indicador está activo."""
    if not xbmc.getCondVisibility("Skin.HasSetting(show_perf)"):
        if perf["at"]:
            for n in PERF_PROPS:
                win.clearProperty("SkinCat.Perf." + n)
            perf["at"] = 0.0
            perf["fps"].clear()
            perf["busy"].clear()
        return
    perf["busy"].append(busy_ms)
    del perf["busy"][:-50]
    if time.time() - perf["at"] < 0.5:
        return
    perf["at"] = time.time()
    try:
        perf["fps"].append(float(xbmc.getInfoLabel("System.FPS").replace(",", ".").split()[0]))
    except (ValueError, IndexError):
        pass
    del perf["fps"][:-20]
    if perf["fps"]:
        win.setProperty("SkinCat.Perf.FpsMin", "%.0f" % min(perf["fps"]))
        win.setProperty("SkinCat.Perf.FpsAvg", "%.0f" % (sum(perf["fps"]) / len(perf["fps"])))
    win.setProperty("SkinCat.Perf.ServiceMs", "%.1f" % (sum(perf["busy"]) / len(perf["busy"])))
    win.setProperty("SkinCat.Perf.ServiceMax", "%.0f" % max(perf["busy"]))
    win.setProperty("SkinCat.Perf.Build", _build_state[0] or "IMDb: en reposo")


def main():
    if win.getProperty(RUNNING) == "1":
        return
    win.setProperty(RUNNING, "1")
    monitor = xbmc.Monitor()
    log("iniciado")
    if db_is_stale():
        threading.Thread(target=build_db, daemon=True).start()
    last = {}
    sigs = {}
    scan_at = 0.0
    rows_at = 0.0
    code_at = 0.0
    was_home, was_modal, bumps, refocus = True, False, [], None
    reload_self = False
    tracker = watch.Tracker(win)
    poll_at = cont_at = 0.0
    pend_since = None
    perf = {"fps": [], "busy": [], "at": 0.0}
    try:
        mtime0 = os.path.getmtime(__file__)
    except (NameError, OSError):
        mtime0 = None
    try:
        while not monitor.abortRequested():
            t_iter = time.perf_counter()
            if mtime0 is not None and time.time() - code_at > 2.0:  # si se despliega una versión nueva, relanzarse
                code_at = time.time()
                try:
                    if os.path.getmtime(__file__) != mtime0:
                        reload_self = True
                        break
                except OSError:
                    pass
            now_home = xbmc.getCondVisibility("Window.IsActive(home)")
            now_modal = xbmc.getCondVisibility(MODAL)
            if now_home and was_modal and not now_modal:
                # Palantir tarda en guardar (p. ej. "Añadir a favoritos" + sincronizar con Trakt): recargar 3 veces
                t = time.time()
                bumps = [(t + 2.5, "se cerró un diálogo"), (t + 8.0, "se cerró un diálogo (2)"), (t + 16.0, "se cerró un diálogo (3)")]
            elif now_home and not was_home:
                bumps = [(time.time() + 0.5, "vuelta al Home")]
            was_home, was_modal = now_home, now_modal
            if bumps and time.time() >= bumps[0][0]:
                why = bumps.pop(0)[1]
                f = bump_reload(why)
                refocus = (f[0], f[1], time.time() + 4.0) if f else None
            if refocus and time.time() >= refocus[2]:  # la fila ya recargó: volver al elemento en el que estabas
                cid, idx, _ = refocus
                refocus = None
                cur = xbmc.getInfoLabel("Container(%d).CurrentItem" % cid)
                if idx > 0 and (not cur.isdigit() or int(cur) - 1 != idx):
                    xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, idx))
            if xbmc.getCondVisibility("Window.IsActive(home)") and time.time() - rows_at > 0.3:
                rows_at = time.time()
                publish_row_sources()
            if xbmc.getCondVisibility(ACTIVE):
                if time.time() - scan_at > 1.0:
                    scan_at = time.time()
                    scan_rows(sigs)
                for key, prefix in SOURCES.items():
                    tag = (xbmc.getInfoLabel(prefix + ".Label"), xbmc.getInfoLabel(prefix + ".UniqueID(tmdb)"), _version)
                    if tag != last.get(key):
                        last[key] = tag
                        publish(key, tag[0], rating_for(imdb_for(prefix)), logo_for(prefix))
                        if key == "Focus":
                            publish_extra(prefix)
            if time.time() - poll_at > 5.0:
                poll_at = time.time()
                tracker.poll()
            if time.time() - cont_at > 1.5:
                cont_at = time.time()
                sync_continue()
                if tmdb_key():
                    win.setProperty("SkinCat.TMDB.State", "Configurada")
                else:
                    win.setProperty("SkinCat.TMDB.State", "Sin configurar: no se muestran logos")
                win.setProperty("SkinCat.Trakt.State", "Configurado" if os.path.exists(os.path.join(DATA_DIR, "trakt_key.txt")) else "Sin configurar: no salen listas de Trakt")
                if win.getProperty("SkinCat.Play.Path"):  # se pulsó OK pero la reproducción no llegó a empezar: descartar
                    pend_since = pend_since or time.time()
                    if time.time() - pend_since > 180 and not tracker.isPlaying():
                        for k in ("Path", "Src", "Season", "Episode", "Resume"):
                            win.clearProperty("SkinCat.Play." + k)
                else:
                    pend_since = None
            sample_perf(perf, (time.perf_counter() - t_iter) * 1000.0)
            monitor.waitForAbort(0.2)
    finally:
        win.clearProperty(RUNNING)
        log("detenido")
    if reload_self:
        log("código actualizado: relanzando")
        xbmc.executebuiltin("RunScript(special://skin/scripts/skincat_imdb.py)")


main()
