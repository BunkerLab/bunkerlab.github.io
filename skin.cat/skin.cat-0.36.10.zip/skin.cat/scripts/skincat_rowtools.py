# -*- coding: utf-8 -*-
"""SkinCat: herramientas para las filas del Home.

  RunScript(special://skin/scripts/skincat_rowtools.py,setkey)
      Pide la clave (o token) de la API de TMDB y la guarda en addon_data/skin.cat/tmdb_key.txt: con ella la skin muestra el
      logo original de cada título en lugar del texto. Vacío = borrar la clave.
  RunScript(special://skin/scripts/skincat_rowtools.py,menu,<fila>)
      Menú de una fila de la tercera columna del selector (Custom_1111_RowPicker.xml): cambiar su contenido, subir, bajar, quitar.
  RunScript(special://skin/scripts/skincat_rowtools.py,remove)
      Quita la fila indicada en Skin.String(picker_row) y sube todas las siguientes un puesto, sin dejar huecos.
      (Skin.SetString con un valor vacío abriría el teclado de Kodi, por eso se usa Skin.Reset para las filas vacías.)
"""
import os
import sys
import re
import time

import xbmc
import xbmcgui
import xbmcvfs

KEY_PATH = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/skin.cat/"), "tmdb_key.txt")
TRAKT_KEY_PATH = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/skin.cat/"), "trakt_key.txt")

TAGS = re.compile(r"\[/?(?:COLOR[^\]]*|B|I|CR)\]", re.I)
MAX_ROWS = 24  # igual que devtools/gen_rows.py
FIELDS = ("path", "title", "pages", "sort", "sortlabel")


def get(n, field):
    return xbmc.getInfoLabel("Skin.String(widget%d%s)" % (n, field))


def put(n, field, value):
    name = "widget%d%s" % (n, field)
    if value:
        xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (name, value.replace('"', "'")))
    else:
        xbmc.executebuiltin("Skin.Reset(%s)" % name)


def count_rows():
    n = 0
    while n < MAX_ROWS and get(n + 1, "path"):
        n += 1
    return n


def bump_rev():
    """Cambia SkinCat.Rows.Rev: la tercera columna del selector lo lleva en su dirección y se vuelve a cargar."""
    xbmcgui.Window(10000).setProperty("SkinCat.Rows.Rev", str(int(time.time() * 1000)))


def refocus(index):
    xbmc.sleep(900)  # deja terminar la recarga de la lista
    xbmc.executebuiltin("SetFocus(300,%d,absolute)" % index)


def remove(row=None):
    if row is None:
        row = xbmc.getInfoLabel("Skin.String(picker_row)")
        row = int(row) if row.isdigit() else 0
    if not 1 <= row <= MAX_ROWS:
        return
    for n in range(row, MAX_ROWS):          # la fila n pasa a ser la n+1
        for f in FIELDS:
            put(n, f, get(n + 1, f))
    for f in FIELDS:                        # la última queda vacía
        put(MAX_ROWS, f, "")
    bump_rev()


def swap(a, b):
    va = {f: get(a, f) for f in FIELDS}
    vb = {f: get(b, f) for f in FIELDS}
    for f in FIELDS:
        put(a, f, vb[f])
        put(b, f, va[f])
    cur = xbmc.getInfoLabel("Skin.String(picker_row)")
    if cur == str(a):      # la marca de "fila que se está editando" acompaña a su contenido
        xbmc.executebuiltin("Skin.SetString(picker_row,%d)" % b)
    elif cur == str(b):
        xbmc.executebuiltin("Skin.SetString(picker_row,%d)" % a)
    bump_rev()


def move_row(a, b):
    """Lleva la fila a a la posición b; las demás se desplazan un hueco (sin tocar su contenido)."""
    if a == b:
        return
    saved = {f: get(a, f) for f in FIELDS}
    step = 1 if b > a else -1
    for n in range(a, b, step):
        for f in FIELDS:
            put(n, f, get(n + step, f))
    for f in FIELDS:
        put(b, f, saved[f])
    cur = xbmc.getInfoLabel("Skin.String(picker_row)")
    if cur.isdigit():
        c, new = int(cur), None
        if c == a:
            new = b
        elif a < b and a < c <= b:
            new = c - 1
        elif b < a and b <= c < a:
            new = c + 1
        if new:
            xbmc.executebuiltin("Skin.SetString(picker_row,%d)" % new)
    bump_rev()


def pick_position(row, total):
    labels = []
    for n in range(1, total + 1):
        t = TAGS.sub("", get(n, "title")).strip() or "Fila %d" % n
        labels.append("%d  ·  %s%s" % (n, t, "      (aquí está ahora)" if n == row else ""))
    choice = xbmcgui.Dialog().select("Mover «%s» a la posición…" % (TAGS.sub("", get(row, "title")).strip() or "fila %d" % row),
                                     labels, preselect=row - 1)
    return choice + 1 if choice >= 0 else 0


def menu(row):
    """OK en una fila de la tercera columna: menú con lo que se puede hacer con ella."""
    if not 1 <= row <= MAX_ROWS or not get(row, "path"):
        return
    total = count_rows()
    opts = [("edit", "Cambiar su contenido")]
    if row > 1:
        opts.append(("up", "\u25b2  Subir una posición"))
    if row < total:
        opts.append(("down", "\u25bc  Bajar una posición"))
    if total > 1:
        opts.append(("moveto", "\u21c5  Mover a otra posición…"))
    opts.append(("remove", "Quitar esta fila"))
    choice = xbmcgui.Dialog().contextmenu([label for _, label in opts])
    if choice < 0:
        return
    action = opts[choice][0]
    if action == "edit":
        xbmc.executebuiltin("Skin.SetString(picker_row,%d)" % row)
        bump_rev()
        xbmc.sleep(300)
        xbmc.executebuiltin("SetFocus(100)")
    elif action == "up":
        swap(row, row - 1)
        refocus(row - 2)
    elif action == "down":
        swap(row, row + 1)
        refocus(row)
    elif action == "moveto":
        dest = pick_position(row, total)
        if dest and dest != row:
            move_row(row, dest)
            refocus(dest - 1)
        else:
            refocus(row - 1)
    elif action == "remove":
        remove(row)
        refocus(max(0, row - 2))


def setkey(kind="tmdb"):
    path, what, ok_msg = (KEY_PATH, "de la API de TMDB (themoviedb.org)", "Clave guardada: los logos aparecerán al navegar") if kind == "tmdb" else \
        (TRAKT_KEY_PATH, "(Client ID) de la API de Trakt (trakt.tv/oauth/applications)", "Client ID guardado: ya sale 'Listas de Trakt' en el selector de filas")
    try:
        with open(path) as f:
            cur = f.read().strip()
    except OSError:
        cur = ""
    new = xbmcgui.Dialog().input("Clave %s. Vacío = borrar" % what, defaultt=cur)
    if new is None or new.strip() == cur:
        return
    new = new.strip()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if new:
        with open(path, "w") as f:
            f.write(new)
        os.chmod(path, 0o600)
        xbmcgui.Dialog().notification("SkinCat", ok_msg, xbmcgui.NOTIFICATION_INFO, 4000)
    elif os.path.exists(path):
        os.remove(path)
        xbmcgui.Dialog().notification("SkinCat", "Clave borrada", xbmcgui.NOTIFICATION_INFO, 3000)


if len(sys.argv) > 1 and sys.argv[1] == "setkey":
    setkey(sys.argv[2] if len(sys.argv) > 2 else "tmdb")


if len(sys.argv) > 1 and sys.argv[1] == "remove":
    remove()
elif len(sys.argv) > 2 and sys.argv[1] == "menu" and sys.argv[2].isdigit():
    menu(int(sys.argv[2]))
