# -*- coding: utf-8 -*-
"""SkinCat: búsqueda en Palantir sin salir de la skin.

Lo lanza Custom_1113_Search.xml (<onload>, solo si la lupa puso SkinCat.Search.Ask=1) y el botón "nueva búsqueda".
Pide el texto con el teclado de Kodi y lo guarda en SkinCat.Search.Query.

Cómo funciona (sin tocar el código de Palantir, usándolo como lo haría un usuario):
  1. Busca en la raíz de Palantir la carpeta "Buscar por título" y la abre (Files.GetDirectory).
     Palantir muestra su teclado virtual; este script lo detecta y le envía el texto (Input.SendText, done).
  2. Palantir devuelve una carpeta por categoría con resultados: "Películas (8)", "Series (2)", ...
     Se guardan (caché 10 min) y se publican en Window(Home):
        SkinCat.Search.Status = searching | ok | empty | error
        SkinCat.Search.Count  = nº de categorías con resultados
        SkinCat.Search.Token  = id de esta búsqueda (las filas de resultados cargan con él)
  3. Las filas de la ventana de búsqueda leen cada categoría con
        plugin://skin.cat/?mode=results&t=<token>&cat=<n>
"""
import hashlib
import json
import os
import re
import sys
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

SKIN_ID = "skin.cat"
ROOT = "plugin://plugin.video.palantir3/"
CACHE_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s/searchcache/" % SKIN_ID)
CACHE_TTL = 10 * 60
TAGS = re.compile(r"\[/?(?:COLOR[^\]]*|B|I|CR)\]", re.I)
win = xbmcgui.Window(10000)


def log(msg):
    xbmc.log("[SkinCat search] %s" % msg, xbmc.LOGINFO)


def jsonrpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def clean(label):
    return TAGS.sub("", label or "").strip()


def cache_file(token):
    return os.path.join(CACHE_DIR, token + ".json")


def feed_keyboard(query, stop):
    """Espera a que Palantir abra su teclado virtual y le escribe el texto."""
    t0 = time.time()
    while not stop.is_set() and time.time() - t0 < 10:
        if xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"):
            time.sleep(0.4)
            jsonrpc("Input.SendText", {"text": query, "done": True})
            return
        time.sleep(0.1)


def run_search(query):
    root = jsonrpc("Files.GetDirectory", {"directory": ROOT, "media": "video"}).get("result", {}).get("files", [])
    entry = next((f for f in root if f.get("filetype") == "directory" and clean(f.get("label")).lower().startswith("buscar")), None)
    if not entry:
        raise RuntimeError("no se encontró la carpeta de búsqueda de Palantir")
    stop = threading.Event()
    t = threading.Thread(target=feed_keyboard, args=(query, stop), daemon=True)
    t.start()
    try:
        res = jsonrpc("Files.GetDirectory", {"directory": entry["file"], "media": "video"})
    finally:
        stop.set()
    files = res.get("result", {}).get("files")
    if files is None:  # Palantir devuelve error cuando no hay resultados o se cancela el teclado
        return []
    return [{"label": f["label"], "file": f["file"]} for f in files
            if f.get("filetype") == "directory" and not clean(f.get("label")).lower().startswith("buscar")]


def ask_query():
    """Teclado de Kodi (con el aspecto de la skin). Devuelve el texto o '' si se cancela."""
    kb = xbmc.Keyboard(win.getProperty("SkinCat.Search.Query"), "Buscar en Palantir")
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else ""


def main():
    ask = win.getProperty("SkinCat.Search.Ask") == "1" or "ask" in sys.argv[1:]
    win.clearProperty("SkinCat.Search.Ask")
    if not ask:  # onload al volver de otra ventana (p. ej. tras abrir una carpeta): no repetir la búsqueda
        return
    query = ask_query()
    if not query:
        if xbmc.getCondVisibility("Window.IsActive(1113)") and not win.getProperty("SkinCat.Search.Token"):
            xbmc.executebuiltin("Action(PreviousMenu)")  # canceló la primera búsqueda: volver al Home
        return
    win.setProperty("SkinCat.Search.Query", query)
    token = hashlib.md5(query.lower().encode("utf-8")).hexdigest()[:12]
    for p in ("Token", "Count"):
        win.clearProperty("SkinCat.Search." + p)
    win.setProperty("SkinCat.Search.Status", "searching")
    os.makedirs(CACHE_DIR, exist_ok=True)
    cats = None
    cf = cache_file(token)
    try:
        if time.time() - os.path.getmtime(cf) < CACHE_TTL:
            with open(cf, "r", encoding="utf-8") as f:
                cats = json.load(f)
    except (OSError, ValueError):
        pass
    try:
        if cats is None:
            log("buscando %r" % query)
            cats = run_search(query)
            if cats:
                with open(cf, "w", encoding="utf-8") as f:
                    json.dump(cats, f)
        log("%d categorías con resultados" % len(cats))
    except Exception as e:
        log("error: %r" % e)
        win.setProperty("SkinCat.Search.Status", "error")
        return
    if not cats:
        win.setProperty("SkinCat.Search.Status", "empty")
        return
    win.setProperty("SkinCat.Search.Count", str(len(cats)))
    win.setProperty("SkinCat.Search.Token", token)
    win.setProperty("SkinCat.Search.Status", "ok")
    # cuando las filas hayan cargado, llevar el foco a la primera
    for _ in range(40):
        time.sleep(0.25)
        if xbmc.getCondVisibility("Window.IsActive(1113)") and xbmc.getInfoLabel("Container(9211).NumItems") not in ("", "0"):
            xbmc.executebuiltin("SetFocus(9211)")
            break


main()
