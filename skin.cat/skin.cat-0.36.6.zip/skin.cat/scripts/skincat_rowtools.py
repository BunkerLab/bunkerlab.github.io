# -*- coding: utf-8 -*-
"""SkinCat: herramientas para las filas del Home.

  RunScript(special://skin/scripts/skincat_rowtools.py,setkey)
      Pide la clave (o token) de la API de TMDB y la guarda en addon_data/skin.cat/tmdb_key.txt: con ella la skin muestra el
      logo original de cada título en lugar del texto. Vacío = borrar la clave.
  RunScript(special://skin/scripts/skincat_rowtools.py,remove)
      Quita la fila indicada en Skin.String(picker_row) y sube todas las siguientes un puesto, sin dejar huecos.
      (Skin.SetString con un valor vacío abriría el teclado de Kodi, por eso se usa Skin.Reset para las filas vacías.)
"""
import os
import sys

import xbmc
import xbmcgui
import xbmcvfs

KEY_PATH = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/skin.cat/"), "tmdb_key.txt")

MAX_ROWS = 24  # igual que devtools/gen_rows.py
FIELDS = ("path", "title", "pages")


def get(n, field):
    return xbmc.getInfoLabel("Skin.String(widget%d%s)" % (n, field))


def put(n, field, value):
    name = "widget%d%s" % (n, field)
    if value:
        xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (name, value.replace('"', "'")))
    else:
        xbmc.executebuiltin("Skin.Reset(%s)" % name)


def remove():
    row = xbmc.getInfoLabel("Skin.String(picker_row)")
    if not row.isdigit() or not 1 <= int(row) <= MAX_ROWS:
        return
    row = int(row)
    for n in range(row, MAX_ROWS):          # la fila n pasa a ser la n+1
        for f in FIELDS:
            put(n, f, get(n + 1, f))
    for f in FIELDS:                        # la última queda vacía
        put(MAX_ROWS, f, "")


if len(sys.argv) > 1 and sys.argv[1] == "remove":
    remove()


def setkey():
    try:
        with open(KEY_PATH) as f:
            cur = f.read().strip()
    except OSError:
        cur = ""
    new = xbmcgui.Dialog().input("Clave o token de la API de TMDB (themoviedb.org). Vacío = borrar", defaultt=cur)
    if new is None or new.strip() == cur:
        return
    new = new.strip()
    os.makedirs(os.path.dirname(KEY_PATH), exist_ok=True)
    if new:
        with open(KEY_PATH, "w") as f:
            f.write(new)
        os.chmod(KEY_PATH, 0o600)
        xbmcgui.Dialog().notification("SkinCat", "Clave guardada: los logos aparecerán al navegar", xbmcgui.NOTIFICATION_INFO, 4000)
    elif os.path.exists(KEY_PATH):
        os.remove(KEY_PATH)
        xbmcgui.Dialog().notification("SkinCat", "Clave borrada", xbmcgui.NOTIFICATION_INFO, 3000)


if len(sys.argv) > 1 and sys.argv[1] == "setkey":
    setkey()
